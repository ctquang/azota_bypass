/* Display-only native lookup. The game's function ALWAYS returns its original value. */
(()=>{
  'use strict';if(globalThis.__ONE8B_VI_NATIVE_INSTALLED)return;globalThis.__ONE8B_VI_NATIVE_INSTALLED=true;
  const api=globalThis.ONE8B_VI,templates=new WeakMap();let attached=false;
  function install(){
    if(attached||window.LANG!=='en'||typeof window.L!=='function')return;
    attached=true;const original=window.L;
    window.L=function(strings,...values){
      const source=original(strings,...values);if(!api.enabled)return source;
      let t=templates.get(strings);
      if(t===undefined){const en=api.data.nativeSource[strings.join('\u0001')];t=en===undefined?null:api.data.text[en]??null;templates.set(strings,t);}
      if(t===null)return source;
      let target=t.replace(/\{(\d+)\}/g,(_,i)=>api.label(String(values[+i])));
      target=target.replace(/\{@(\w+)\}/g,(_,k)=>{try{return typeof window.helpEn==='function'?api.translate(window.helpEn(k)):'findahelpline.com';}catch{return 'findahelpline.com';}});
      // Same engine: no CustomEvent, JSON serialization or second copy of the dictionary.
      api.registerPair(source,target);return source;
    };
    if(typeof CanvasRenderingContext2D!=='undefined')for(const k of ['fillText','strokeText','measureText']){
      const f=CanvasRenderingContext2D.prototype[k];CanvasRenderingContext2D.prototype[k]=function(text,...args){return f.call(this,api.enabled?api.translate(String(text)):text,...args);};
    }
  }
  document.addEventListener('one8b-vi-sync',e=>{if(e.detail==='on')api.enabled=true;else if(e.detail==='off')api.enabled=false;install();});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
})();
