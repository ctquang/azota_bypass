/* DOM-only presentation. Microtask updates before paint; 3ms work slices for bursts. */
(()=>{
  'use strict';if(globalThis.__ONE8B_VI_CONTENT_INSTALLED)return;globalThis.__ONE8B_VI_CONTENT_INSTALLED=true;
  const api=globalThis.ONE8B_VI,originalNodes=new WeakMap(),originalAttrs=new WeakMap();
  const blocked='script,style,noscript,code,pre,kbd,[contenteditable]:not([contenteditable="false"]),[data-one8b-vi-ui],#fbText,#shareNote';
  const textBlocked=blocked+',textarea,input';
  const attrs=['title','aria-label','placeholder','alt'];
  let enabled=api.enabled,observer=null,scheduled=false,raf=0,cursor=null,initialized=false;
  const pending=new Set(),stats={changed:0,groups:0,passes:0,maxSliceMs:0,revision:api.data.revision};
  const compatible=()=>location.pathname.startsWith('/en/')||location.pathname==='/en'||document.documentElement.lang==='en';
  const getSource=n=>{const s=originalNodes.get(n);return s&&n.nodeValue===s.display?s.source:n.nodeValue;};
  function write(n,out){
    if(n.nodeValue===out)return;
    originalNodes.set(n,{source:getSource(n),display:out});n.nodeValue=out;stats.changed++;
  }
  function translateNode(n){
    if(!n.parentElement||n.parentElement.closest(textBlocked)||!n.isConnected)return;
    const h=n.parentElement.closest('h1');if(h&&api.proper.has(api.normalize(h.textContent)))return;
    const s=originalNodes.get(n);if(s&&n.nodeValue===s.display)return;
    const now=n.nodeValue;let out=api.translate(now);
    // In family rows, a bare number + years denotes age, not a duration.
    // Keep this scoped: years in bond notes, job descriptions and finances stay năm.
    if(n.parentElement.matches('#fam > .row > span:last-child, .deadfam .fam > .row > span:last-child'))out=out.replace(/(^|\s·\s)(\d+)\s+năm\b/g,'$1$2 tuổi');
    if(out!==now)write(n,out);else if(s)originalNodes.delete(n);
  }
  function translateAttrs(el){
    if(!el.isConnected||el.closest(blocked))return;
    const records=originalAttrs.get(el)||new Map();
    for(const k of attrs){
      const now=el.getAttribute(k);if(now===null)continue;
      const saved=records.get(k);if(saved&&now===saved.display)continue;
      const out=api.translate(now);
      if(out!==now){records.set(k,{source:now,display:out});el.setAttribute(k,out);}else if(saved)records.delete(k);
    }
    if(records.size)originalAttrs.set(el,records);
  }
  const inline=new Set(['B','STRONG','EM','I','SPAN','A','SMALL','U','S','SUP','SUB']);
  function leafTexts(el){
    const a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);for(let n=w.nextNode();n;n=w.nextNode())a.push(n);return a;
  }
  function assign(nodes,value){
    if(!nodes.length)return value==='';
    write(nodes[0],value);for(let i=1;i<nodes.length;i++)write(nodes[i],'');return true;
  }
  function group(el){
    // Preserve all elements, IDs and handlers. Only distribute text between inline anchors.
    if(!/^(P|BUTTON|LI|DIV|LABEL|TD|TH|FIGCAPTION|H[1-6])$/.test(el.tagName)||el.closest(textBlocked)||!el.children.length||el.childNodes.length>20)return;
    const nodes=[...el.childNodes];
    if(!nodes.some(n=>n.nodeType===Node.TEXT_NODE&&/\S/.test(getSource(n))))return;
    if(nodes.some(n=>n.nodeType!==Node.TEXT_NODE&&(!inline.has(n.tagName)||n.querySelector('button,input,textarea,select,svg,canvas,img,iframe,br,div,p'))))return;
    if(el.tagName==='H1'&&api.proper.has(api.normalize(el.textContent)))return;
    const all=leafTexts(el);if(!all.length||all.length>32)return;
    const source=all.map(getSource).join(''),target=api.translate(source);if(target===source)return;
    // Locate translated inline anchors in the same order. Abort rather than guess/reorder.
    const plan=[];let between=[],at=0;
    for(const node of nodes){
      if(node.nodeType===Node.TEXT_NODE){between.push(node);continue;}
      const leaves=leafTexts(node),original=leaves.map(getSource).join(''),anchor=api.translate(original);
      if(!anchor.trim())return;
      const pos=target.indexOf(anchor,at);if(pos<at)return;
      const before=target.slice(at,pos);if(before&&!between.length)return;
      plan.push([between,before],[leaves,anchor]);between=[];at=pos+anchor.length;
    }
    const tail=target.slice(at);if(tail&&!between.length)return;plan.push([between,tail]);
    for(const [nodes,value]of plan)assign(nodes,value);stats.groups++;
  }
  function visit(n){
    if(n.nodeType===Node.TEXT_NODE)translateNode(n);
    else if(n.nodeType===Node.ELEMENT_NODE){if(n.hasAttributes())translateAttrs(n);group(n);}
  }
  function makeCursor(root){
    if(!root.isConnected)return null;
    if(root.nodeType===Node.TEXT_NODE)return {root,first:true,walker:null};
    if(root.nodeType!==Node.ELEMENT_NODE||root.matches(blocked))return null;
    return {root,first:true,walker:document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT,{acceptNode(n){return n.nodeType===Node.ELEMENT_NODE&&n.matches(blocked)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT;}})};
  }
  function selectRoot(n){
    if(n.nodeType===Node.TEXT_NODE){let el=n.parentElement;for(let i=0;i<3&&el&&inline.has(el.tagName);i++)el=el.parentElement;return el||n;}
    return n;
  }
  function schedule(){if(!scheduled){scheduled=true;queueMicrotask(flush);}}
  function enqueue(node){
    if(!enabled||!compatible()||!node?.isConnected)return;
    node=selectRoot(node);
    // Deduplicate ancestors so a burst never walks the same subtree for every child.
    for(let p=node;p;p=p.parentNode)if(pending.has(p))return;
    pending.add(node);schedule();
  }
  function flush(){
    scheduled=false;if(!enabled)return;
    const begin=performance.now();let items=0;
    while(cursor||pending.size){
      if(!cursor){const root=pending.values().next().value;pending.delete(root);cursor=makeCursor(root);if(!cursor)continue;}
      let n;
      if(cursor.first){n=cursor.root;cursor.first=false;}else n=cursor.walker?.nextNode();
      if(!n){cursor=null;continue;}
      if(n.isConnected)visit(n);items++;
      if(items%16===0&&performance.now()-begin>=3)break;
    }
    const duration=performance.now()-begin;stats.passes++;stats.maxSliceMs=Math.max(stats.maxSliceMs,duration);
    if(cursor||pending.size){
      // Burst fallback yields to the browser. New small mutations still use microtasks.
      if(!raf)raf=requestAnimationFrame(()=>{raf=0;schedule();});
    }
  }
  function observe(){
    if(!compatible())return;
    observer??=new MutationObserver(records=>{
      for(const m of records){
        if(m.type==='characterData'){const s=originalNodes.get(m.target);if(s&&m.target.nodeValue===s.display)continue;enqueue(m.target);}
        else if(m.type==='attributes'){
          const saved=originalAttrs.get(m.target)?.get(m.attributeName);if(saved&&m.target.getAttribute(m.attributeName)===saved.display)continue;enqueue(m.target);
        }else for(const n of m.addedNodes)enqueue(n);
      }
    });
    observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:[...attrs,'hidden']});enqueue(document.body);
  }
  function restore(){
    observer?.disconnect();pending.clear();cursor=null;cancelAnimationFrame(raf);raf=0;
    const w=document.createTreeWalker(document.body,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);
    for(let n=w.nextNode();n;n=w.nextNode()){
      if(n.nodeType===Node.TEXT_NODE){const s=originalNodes.get(n);if(s&&n.nodeValue===s.display)n.nodeValue=s.source;originalNodes.delete(n);}
      else{const a=originalAttrs.get(n);if(a)for(const [k,s]of a)if(n.getAttribute(k)===s.display)n.setAttribute(k,s.source);originalAttrs.delete(n);}
    }
  }
  function setEnabled(value,persist=false){
    const changed=enabled!==!!value;enabled=!!value;api.enabled=enabled;
    if(!initialized||changed){if(enabled)observe();else restore();initialized=true;}
    button.textContent=compatible()?(enabled?'VI · Đang bật':'EN · Bản gốc'):'Mở bản English';
    button.title='Nhấn để bật/tắt tiếng Việt';
    if(persist)document.dispatchEvent(new CustomEvent('one8b-vi-persist',{detail:enabled?'on':'off'}));
  }
  document.addEventListener('one8b-vi-sync',e=>{if(e.detail==='on'||e.detail==='off')setEnabled(e.detail==='on');});
  const host=document.createElement('div');host.setAttribute('data-one8b-vi-ui','');const shadow=host.attachShadow({mode:'open'}),style=document.createElement('style');
  style.textContent=':host{position:fixed;bottom:14px;left:14px;z-index:2147483646}button{border:1px solid #58987e;background:#113f32;color:#fff;border-radius:999px;padding:9px 13px;font:600 12px system-ui;box-shadow:0 3px 14px #0003;cursor:pointer}button:focus-visible{outline:3px solid #d2a15a;outline-offset:3px}';
  const button=document.createElement('button');button.type='button';button.addEventListener('click',()=>{if(!compatible())location.href='https://1in8b.life/en/';else setEnabled(!enabled,true);});
  shadow.append(style,button);document.documentElement.append(host);setEnabled(api.enabled);document.dispatchEvent(new CustomEvent('one8b-vi-request-setting'));
  globalThis.__ONE8B_VI_TEST={stats,setEnabled,translate:api.translate,source:n=>getSource(n),diagnostics:api.diagnostics};
})();
