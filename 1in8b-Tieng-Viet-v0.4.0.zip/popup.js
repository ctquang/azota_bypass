'use strict';
const checkbox=document.getElementById('enabled');
chrome.storage.local.get({one8bViEnabled:true},r=>{checkbox.checked=r.one8bViEnabled;});
checkbox.addEventListener('change',()=>chrome.storage.local.set({one8bViEnabled:checkbox.checked}));
document.getElementById('open').addEventListener('click',()=>chrome.tabs.create({url:'https://1in8b.life/en/'}));
