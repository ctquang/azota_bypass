/* Isolated world: only preference storage. No dictionary, translator or game data. */
(()=>{
  'use strict';
  const send=v=>document.dispatchEvent(new CustomEvent('one8b-vi-sync',{detail:v?'on':'off'}));
  chrome.storage.local.get({one8bViEnabled:true},r=>send(r.one8bViEnabled));
  document.addEventListener('one8b-vi-request-setting',()=>chrome.storage.local.get({one8bViEnabled:true},r=>send(r.one8bViEnabled)));
  document.addEventListener('one8b-vi-persist',e=>{if(e.detail==='on'||e.detail==='off')chrome.storage.local.set({one8bViEnabled:e.detail==='on'});});
  chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.one8bViEnabled)send(c.one8bViEnabled.newValue);});
})();
