/* One engine in MAIN. Exact-match first, lazy template compilation, bounded caches. */
(() => {
  'use strict';
  const data=globalThis.ONE8B_VI_DATA;if(!data||globalThis.ONE8B_VI)return;
  const start=performance.now();
  const normalize=s=>String(s).replace(/\u2060/g,'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const decode=s=>s.replace(/<!--[^]*?-->/g,'').replace(/<\/?(?:p|div|h[1-6]|li|br|tr|td|th|ul|ol)\b[^>]*>/gi,' ').replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'");
  const proper=new Set(data.proper.map(normalize)),names=new Set(data.names.map(normalize));
  const text=new Map(),folded=new Map(),cache=new Map(),dynamic=new Map();
  const slots=/\{(\d+|@\w+|screen)\}/g,hasSlots=s=>/\{(?:\d+|@\w+|screen)\}/.test(s);
  const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const words=s=>(s.toLowerCase().match(/[a-z][a-z'-]+/g)||[]);
  const manual=new Set(data.manualKeys.map(x=>normalize(decode(x))));
  const add=(a,b)=>{a=normalize(decode(a));b=normalize(decode(b));if(a&&b&&!proper.has(a)){text.set(a,b);folded.set(a.toLowerCase(),b);}};
  for(const [a,b]of Object.entries(data.text)){
    add(a,b);
    if(a.includes('<')){
      const aa=a.split(/<[^>]+>/),bb=b.split(/<[^>]+>/);
      if(aa.length===bb.length)for(let i=0;i<aa.length;i++)add(aa[i],bb[i]);
    }
  }
  // Whole standalone labels outrank leaves inferred from large HTML blocks.
  // An untranslated "Hobbies" leaf must not erase the standalone "Sở thích" entry.
  for(const [a,b] of Object.entries(data.text))if(!a.includes('<'))add(a,b);
  for(const k of data.manualKeys)if(data.text[k]!==undefined)add(k,data.text[k]);
  const singular={years:'year',people:'person',children:'child',months:'month',times:'time',days:'day',kids:'kid',siblings:'sibling',grandchildren:'grandchild',lives:'life',countries:'country',brothers:'brother',sisters:'sister',sons:'son',daughters:'daughter',friends:'friend',babies:'baby',decisions:'decision',points:'point',weeks:'week',hours:'hour',minutes:'minute',seconds:'second',households:'household',jobs:'job'};
  for(const [a,b]of [...text]){
    const x=a.replace(/\b1 ([a-z-]+)\b/g,(m,w)=>singular[w]?'1 '+singular[w]:m).replace(/\ba (?=[aeiou])(?!(?:uni|use|usu|uti|eu|one\b|once\b))/g,'an ');
    if(x!==a)add(x,b);
  }
  // Prefix matching is permitted only before prices, counts or UI separators.
  // It is NOT a word-by-word replacement pass over arbitrary sentences.
  const labelIndex=new Map();
  for(const [a,b]of text){
    if(hasSlots(a)||hasSlots(b)||a.length<2||a.length>180||/[.!?]$/.test(a)||proper.has(a)||names.has(a)||a===b)continue;
    const k=a.slice(0,2).toLowerCase();if(!labelIndex.has(k))labelIndex.set(k,[]);labelIndex.get(k).push({a,b});
  }
  for(const list of labelIndex.values())list.sort((a,b)=>b.a.length-a.a.length);
  const functionWords=new Set(['a','an','the','and','in','at','of','to','for','from','with','on','is','by','your','now']);
  const templates=[],frequency=new Map(),index=new Map(),prefixIndex=new Map();
  let compiled=0;
  for(const [a,b]of text){
    if(!hasSlots(a))continue;
    const literal=a.replace(slots,' '),anchors=[...new Set(words(literal))];
    if(!anchors.length||literal.replace(/[^a-z]/gi,'').length<2)continue;
    if(anchors.every(x=>functionWords.has(x))&&!(manual.has(a)&&/^now in \{\d+\}$/i.test(a)))continue;
    const first=a.split(/\{(?:\d+|@\w+|screen)\}/,1)[0].toLowerCase();
    const t={a,b,anchors,first,re:null,ids:null,numericIds:[],weight:a.replace(slots,'').length+(manual.has(a)?0.05:0)-(a.match(/\{(?:\d+|@\w+|screen)\}/g)||[]).length*0.001};
    for(const m of a.matchAll(/\{(\d+)\}\s+(?:other\s+)?(?:countries|years?|months?|days?|hours?|minutes?|seconds?|people|children|babies|points|households)\b/gi))t.numericIds.push(m[1]);
    for(const m of a.matchAll(/\bage\s+\{(\d+)\}/gi))t.numericIds.push(m[1]);
    if(/^at \{\d+\}$/i.test(a))t.numericIds.push(a.match(/\{(\d+)\}/)[1]);
    templates.push(t);for(const w of anchors)frequency.set(w,(frequency.get(w)||0)+1);
    // A literal adjacent to a value is not a complete word in the rendered string.
    if(first.length>=2&&!/\s$/.test(first)){
      const key=first.slice(0,2);if(!prefixIndex.has(key))prefixIndex.set(key,[]);prefixIndex.get(key).push(t);
    }
  }
  for(const t of templates){
    const k=t.anchors.reduce((a,b)=>frequency.get(a)<=frequency.get(b)?a:b);
    if(!index.has(k))index.set(k,[]);index.get(k).push(t);
  }
  function compile(t){
    if(t.re)return;
    const ids=[],parts=[];let at=0,m;slots.lastIndex=0;
    while((m=slots.exec(t.a))){parts.push(escape(t.a.slice(at,m.index)).replace(/ /g,'\\s+'));parts.push('([^]*?)');ids.push(m[1]);at=m.index+m[0].length;}
    parts.push(escape(t.a.slice(at)).replace(/ /g,'\\s+'));
    t.ids=ids;t.re=new RegExp('^'+parts.join('')+'$','i');compiled++;
  }
  function getExact(n){const b=text.get(n)??folded.get(n.toLowerCase());return b!==undefined&&!hasSlots(b)?b:dynamic.get(n)??b;}
  function knownAtom(value){
    const n=normalize(value).replace(/\s*[·,;:.!?▾]+$/,'').trim();if(proper.has(n)||names.has(n))return true;
    const b=getExact(n);if(b!==undefined&&!hasSlots(b))return true;
    if(/^\d+(?:[.,]\d+)*(?:\s+(?:years?|months?|million|billion|thousand|siblings?|brothers? and sisters?))?$/.test(n))return true;
    // Two or more capitalized tokens are conservatively treated as a proper name.
    return /^(?:[A-ZÀ-Ỹ][\p{L}'’-]+)(?:\s+[A-ZÀ-Ỹ][\p{L}'’-]+){1,5}$/u.test(n);
  }
  function label(value,depth=0){
    if(typeof value!=='string')return String(value);
    const n=normalize(value);
    if(proper.has(n)||names.has(n)||depth>5)return value;
    if(/<[^>]+>/.test(value)){const exact=data.text[value];if(exact!==undefined&&!hasSlots(exact))return exact===n?exact:refine(exact);return value.split(/(<[^>]+>)/).map(x=>x.startsWith('<')?x:label(x,depth+1)).join('');}
    const b=memo(n,depth+1);if(b===n)return value;
    return value.match(/^\s*/)[0]+b+value.match(/\s*$/)[0];
  }
  let refining=0;
  function refine(b){
    if(refining>=2)return b;
    if(!/[.!?]\s+[A-Za-z]/.test(b)||!/[À-ỹ]/.test(b))return b;
    refining++;try{return b.split(/(?<=[.!?])\s*(?=[A-Z])/).map(x=>/[À-ỹ]/.test(x)||proper.has(x)?x:core(x,4)).join(' ');}finally{refining--;}
  }
  const effectNames={Happiness:'Hạnh phúc',Health:'Sức khỏe',Relationships:'Các mối quan hệ',Relations:'Các mối quan hệ',Knowledge:'Kiến thức',Family:'Gắn kết gia đình',Income:'Thu nhập',Promotion:'Thăng tiến',Loneliness:'Cô đơn'};
  function effects(n){
    const re=/\b(Happiness|Health|Relationships|Relations|Knowledge|Family|Income|Promotion|Loneliness)\s*(a little\s*)?([+−–\-↑↓])\s*(\d+(?:[.,]\d+)*)?/g;
    const matches=[...n.matchAll(re)];if(!matches.length)return null;
    const rest=n.replace(re,'').replace(/[\s·,;|]/g,'');if(rest)return null;
    return matches.map(m=>effectNames[m[1]]+(m[2]?' giảm nhẹ':'')+m[3]+(m[4]||'')).join(' · ');
  }
  const unit={year:'năm',month:'tháng',day:'ngày',hour:'giờ',minute:'phút',second:'giây',million:'triệu',billion:'tỷ',thousand:'nghìn'};
  function core(n,depth=0){
    if(depth>6||proper.has(n)||names.has(n))return n;
    if(/^\([^]*\)$/.test(n)){const a=n.slice(1,-1),b=label(a,depth+1);if(a!==b)return '('+b+')';}
    const numbered=/^(\d+(?:[.,]\d+)*)\s+(years?|months?|days?|hours?|minutes?|seconds?|million|billion|thousand)$/i.exec(n);
    if(numbered)return numbered[1]+' '+unit[numbered[2].toLowerCase().replace(/s$/,'')];
    const exact=getExact(n);if(exact!==undefined&&!hasSlots(exact))return exact===n?exact:refine(exact);
    const effect=effects(n);if(effect!==null)return effect;
    const candidates=new Set(prefixIndex.get(n.toLowerCase().slice(0,2))||[]);
    for(const w of new Set(words(n)))for(const t of index.get(w)||[])candidates.add(t);
    const sorted=[...candidates].sort((a,b)=>b.weight-a.weight);
    for(const t of sorted){
      // Generic "X and Y" must never count as a complete translation of a paragraph.
      if(/^\{\d+\} and \{\d+\}$/.test(t.a)&&n.length>110)continue;
      compile(t);const m=t.re.exec(n);if(!m)continue;
      const values={};let consistent=true;
      t.ids.forEach((id,i)=>{if(values[id]!==undefined&&values[id]!==m[i+1])consistent=false;values[id]=m[i+1];});
      if(!consistent)continue;
      if(t.a.replace(slots,'').replace(/[^A-Za-z]/g,'').length<=12&&Object.values(values).some(x=>/[A-Za-z]/.test(x)&&!knownAtom(x)))continue;
      if(t.numericIds.some(id=>!/^[-+−]?[\d][\d.,/–\- ]*(?:\s+(?:million|billion|thousand|hundred))?$|^(?:one|two|three|four|five|six|seven|eight|nine|ten|many|few|several)$/i.test(values[id]?.trim()||'')))continue;
      return refine(t.b.replace(slots,(_,id)=>label(values[id]??'{'+id+'}',depth)));
    }
    // Structured mini-log: keep the person's name and country, translate status/cause.
    const peer=/^(.+?\s*\([^()]+\):)\s*(.+)$/.exec(n);
    if(peer&&(knownAtom(peer[1].replace(/\s*\([^()]+\):$/,''))||(/^[\p{L}'’.-]+(?:\s+[\p{L}'’.-]+){0,5}\s*\(/u.test(peer[1])&&proper.has(peer[1].match(/\(([^()]+)\):$/)?.[1])))){const out=memo(peer[2],depth+1);if(out!==peer[2])return peer[1]+' '+out;}
    const cohort=/^Born in the same second\s*[—–-]\s*(.+)$/i.exec(n);
    if(cohort)return 'Chào đời cùng một giây — '+memo(cohort[1],depth+1);
    if(n.length<130&&n.includes(' and ')){const parts=n.split(' and ');if(parts.length===2&&parts.every(knownAtom))return parts.map(x=>label(x,depth+1)).join(' và ');}
    if(depth<3){const parts=n.split(/(?<=[.!?])\s*(?=[A-Z])/);if(parts.length>1){const out=parts.map(x=>memo(x,depth+1));if(out.some((x,i)=>x!==parts[i]))return out.join(' ');}}
    const lower=n.toLowerCase();
    for(const entry of labelIndex.get(lower.slice(0,2))||[]){
      if(!lower.startsWith(entry.a.toLowerCase()))continue;
      const tail=n.slice(entry.a.length);if(!tail)continue;
      if(!/^\s*(?:[·,:;.!?▾()[\]…]|(?:US)?[$€£¥₩]\s*[-+−]?\d|[-+−]?\d)/.test(tail))continue;
      const out=tail.trim()?memo(tail.trim(),depth+1):tail;
      const leading=tail.match(/^\s*/)[0];
      return entry.b+leading+out;
    }
    if(n.includes(' · ')){
      const a=n.split(' · '),b=a.map(x=>memo(x,depth+1));if(b.some((x,i)=>x!==a[i]))return b.join(' · ');
    }
    if(n.endsWith(' ▾')){const a=n.slice(0,-2),b=memo(a,depth+1);if(a!==b)return b+' ▾';}
    const decoration=/^([^A-Za-z0-9À-ỹ{]+)([A-Za-z][^]*)$/.exec(n);
    if(decoration){const b=memo(decoration[2],depth+1);if(b!==decoration[2])return decoration[1]+b;}
    if(depth<2){
      const a=n.split(/(?<=[.!?])\s*(?=[A-Z])/);
      if(a.length>1){const b=a.map(x=>memo(x,depth+1));if(b.some((x,i)=>x!==a[i]))return b.join(' ');}
    }
    return n;
  }
  function memo(n,depth=0){
    if(proper.has(n))return n;
    // Do not cache partial recursive results under the same key as a full translation.
    if(depth)return core(n,depth);
    if(cache.has(n))return cache.get(n);
    const b=core(n);cache.set(n,b);if(cache.size>10000)cache.delete(cache.keys().next().value);return b;
  }
  function translate(value){
    if(typeof value!=='string'||!/[A-Za-z]/.test(value))return value;
    const n=normalize(value);if(!n||proper.has(n))return value;
    const b=memo(n);if(b===n)return value;
    return value.match(/^\s*/)[0]+b+value.match(/\s*$/)[0];
  }
  function registerPair(source,target){
    if(typeof source!=='string'||typeof target!=='string'||source===target)return;
    const put=(a,b)=>{
      a=normalize(decode(a));b=normalize(decode(b));
      if(!a||!b||a===b||proper.has(a)||dynamic.get(a)===b)return;
      dynamic.set(a,b);cache.delete(a);
      if(dynamic.size>12000){const old=dynamic.keys().next().value;dynamic.delete(old);cache.delete(old);}
    };
    put(source,target);
    const aa=source.split(/<[^>]+>/),bb=target.split(/<[^>]+>/);
    const signature=x=>(x.match(/<[^>]+>/g)||[]).map(t=>t.replace(/(?:aria-label|title|placeholder|alt)="[^"]*"/g,'')).join('');
    if(aa.length===bb.length&&signature(source)===signature(target))for(let i=0;i<aa.length;i++)put(aa[i],bb[i]);
  }
  globalThis.ONE8B_VI={data,translate,label,registerPair,normalize,proper,names,enabled:true,
    diagnostics:()=>({initializationMs:globalThis.ONE8B_VI.initMs,templates:templates.length,compiled,cache:cache.size,dynamic:dynamic.size})};
  globalThis.ONE8B_VI.initMs=performance.now()-start;
})();
