(() => {
  // ── DATA: ưu tiên cache remote từ chrome.storage.local, fallback về bundled ──
  // Nếu server chết / chưa cập nhật → vẫn dùng bundled trong answers.js
  const BUNDLED = globalThis.AZOTA_ANSWER_DATA || {};
  let DATA = BUNDLED;            // sẽ được thay bằng remote nếu có
  let DATA_SOURCE = "bundled";   // "bundled" | "remote"

  // Lấy remote cache từ background (qua message)
  try {
    chrome.runtime.sendMessage({ type: "AZOTA_GET_UPDATE_STATUS" }, (res) => {
      if (chrome.runtime.lastError) return;
      if (res && res.remoteData && res.remoteData.exams) {
        DATA = res.remoteData.exams;
        DATA_SOURCE = "remote";
      }
    });
  } catch { /* dùng bundled */ }

  // ════════════════════════════════════════════════════════════════════════════
  //  TROLL MODE – giả lỗi "Azota vừa cập nhật trang", tool vẫn hoạt động bình thường
  // ════════════════════════════════════════════════════════════════════════════
  (function trollConsole() {
    if (!location.hostname.endsWith("azota.vn")) return;

    // 1) Một dòng warning duy nhất – đúng kiểu Chrome DevTools
    console.warn(
      "%c⚠ %cAzota vừa cập nhật giao diện – trình tự động điền hiện tạm thời không khả dụng.\n" +
      "   Tham khảo: https://azota.vn/help/known-issues",
      "color:#f59e0b;font:600 13px sans-serif",
      "color:inherit"
    );

    // 2) Toast cam chanh nhỏ, tự ẩn sau 6s
    setTimeout(() => {
      if (document.getElementById("azota-troll-toast")) return;
      const toast = document.createElement("div");
      toast.id = "azota-troll-toast";
      toast.innerHTML =
        '<div style="display:flex;gap:8px;align-items:center">' +
          '<span style="font-size:16px">⚠</span>' +
          '<div style="flex:1;font-size:12.5px;line-height:1.4">' +
            'Trang Azota vừa cập nhật, tính năng tự động điền tạm dừng. ' +
            '<a href="https://azota.vn/help/known-issues" target="_blank" ' +
               'style="color:#fbbf24;text-decoration:underline;margin-left:4px">Xem chi tiết</a>' +
          '</div>' +
          '<span style="cursor:pointer;opacity:.6;font-size:16px;line-height:1" ' +
                'onclick="this.parentNode.parentNode.remove()">×</span>' +
        '</div>';
      Object.assign(toast.style, {
        position:        "fixed",
        bottom:          "20px",
        left:            "50%",
        transform:       "translateX(-50%)",
        zIndex:          "2147483647",
        maxWidth:        "480px",
        padding:         "8px 12px",
        borderRadius:    "8px",
        background:      "rgba(28,25,23,.94)",
        color:           "#fef3c7",
        border:          "1px solid #f59e0b",
        boxShadow:       "0 4px 14px rgba(0,0,0,.25)",
        font:            '500 12.5px/1.4 "Segoe UI", Arial, sans-serif',
        animation:       "azota-troll-in .3s ease-out",
      });
      const s = document.createElement("style");
      s.textContent = "@keyframes azota-troll-in{from{opacity:0;transform:translate(-50%,6px)}to{opacity:1;transform:translateX(-50%)}}";
      document.head.appendChild(s);
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 6_000);
    }, 300);
  })();

  let timer = null;
  let finishedForUrl = false;

  // ─── Chuẩn hóa văn bản ─────────────────────────────────────────────────────
  // 1. Unicode NFC
  // 2. Loại bỏ thẻ HTML (an toàn vì đang xử lý innerText, nhưng giữ lại để
  //    phòng trường hợp text chứa mã HTML thô từ clipboard)
  // 3. Loại nhãn a) b) c) d) (cả chữ thường và hoa) ở đầu chuỗi
  // 4. Thu gọn khoảng trắng
  const normalize = (value = "") =>
    value
      .normalize("NFC")
      .replace(/<[^>]*>/g, " ")               // loại thẻ HTML thô
      .replace(/^\s*[a-dA-D][.)]\s*/u, "")    // loại nhãn a) b) c) d)
      .replace(/\s+/g, " ")
      .trim();

  // So sánh rút gọn (xoá hết khoảng trắng) – dùng để khớp mờ
  const compact = (value = "") => normalize(value).replace(/\s/g, "");

  // ─── Lấy mã đề từ URL ──────────────────────────────────────────────────────
  // URL thực tế: https://azota.vn/vi/test/take-test/{examId}/{idx}/{code}
  // Ví dụ: https://azota.vn/vi/test/take-test/86678280/0/ftgyrl
  function examHash() {
    const m = location.pathname.match(/\/test\/take-test\/[^/]+\/[^/]+\/([^/?#]+)/i);
    return m ? m[1].toLowerCase() : "";
  }

  // ─── Đọc nội dung văn bản của một phương án / nhận định ───────────────────
  function itemText(row) {
    // Ưu tiên lấy phần tử .answer-content (bỏ nhãn .font-medium như A/B/C/D)
    const content = row.querySelector(".answer-content");
    if (content) {
      const clone = content.cloneNode(true);
      clone.querySelector(".font-medium")?.remove();
      return normalize(clone.innerText || clone.textContent || "");
    }
    return normalize(row.innerText || row.textContent || "");
  }

  // ─── So sánh hai chuỗi văn bản ─────────────────────────────────────────────
  function sameText(a, b) {
    const x = compact(a);
    const y = compact(b);
    if (!x || !y) return false;
    return x === y || x.startsWith(y) || y.startsWith(x);
  }

  // ─── Gán giá trị cho textarea (kích hoạt reactive framework) ───────────────
  function setTextareaValue(element, value) {
    const setter = Object.getOwnPropertyDescriptor(
      HTMLTextAreaElement.prototype,
      "value"
    )?.set;
    if (!setter) return;
    setter.call(element, String(value));
    element.dispatchEvent(new Event("input",  { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.dispatchEvent(new Event("blur",   { bubbles: true }));
  }

  // ─── Điền câu hỏi trong một lần thử ────────────────────────────────────────
  // limit = 0 → điền tất cả; limit > 0 → chỉ điền N câu đầu tiên TRÊN LINK AZOTA (theo thứ tự hiển thị)
  function fillExam(questionMap, limit = 0) {
    let filled   = 0;
    let expected = 0;
    const unmatched = [];

    // Lấy các câu hỏi theo đúng thứ tự hiển thị từ trên xuống dưới trên trang làm bài Azota (Câu 1, 2, 3...)
    const allDomQuestions = [...document.querySelectorAll('[id^="question_render_element_"]')];
    const targetQuestions = limit > 0 ? allDomQuestions.slice(0, limit) : allDomQuestions;

    for (let index = 0; index < targetQuestions.length; index++) {
      const qEl = targetQuestions[index];
      const qNum = index + 1;
      const questionId = qEl.id.replace(/^question_render_element_/, "");
      const spec = questionMap[questionId];

      if (!spec) {
        unmatched.push(`Câu ${qNum} (ID: ${questionId}): không có trong dữ liệu`);
        continue;
      }

      expected += spec.type === "tf" ? spec.items.length : 1;

      // ── Câu nhiều lựa chọn (mc) ─────────────────────────────────────────
      if (spec.type === "mc") {
        const rows = [...qEl.querySelectorAll(".item-answer")];
        const row  = rows.find((node) => sameText(itemText(node), spec.text));
        const btn  = row?.querySelector("button");
        if (btn) {
          btn.click();
          filled += 1;
        } else {
          unmatched.push(`Câu ${qNum}: không tìm thấy phương án`);
        }
        continue;
      }

      // ── Câu Đúng/Sai (tf) ───────────────────────────────────────────────
      if (spec.type === "tf") {
        for (let i = 0; i < spec.items.length; i++) {
          const item = spec.items[i];
          // Lấy phần trước "→" để khớp (nếu text dài có kèm chú thích)
          const needle = item.text.split("→")[0].trim();
          const rows   = [...qEl.querySelectorAll(".item-answer")];
          const row    = rows.find((node) => sameText(itemText(node), needle));
          const btn    = row && [...row.querySelectorAll("button")]
            .find((node) => node.innerText.trim() === item.value);
          if (btn) {
            btn.click();
            filled += 1;
          } else {
            unmatched.push(`Câu ${qNum} ý ${i + 1}: không tìm thấy nút ${item.value}`);
          }
        }
        continue;
      }

      // ── Câu trả lời ngắn (short) ─────────────────────────────────────────
      if (spec.type === "short") {
        const textarea = qEl.querySelector("textarea");
        if (textarea) {
          setTextareaValue(textarea, spec.value);
          filled += 1;
        } else {
          unmatched.push(`Câu ${qNum}: không tìm thấy ô nhập`);
        }
      }
    }

    return { 
      filled, 
      expected, 
      unmatched, 
      limit, 
      domQuestionCount: allDomQuestions.length,
      targetCount: targetQuestions.length 
    };
  }

  // ─── Hiển thị thông báo nổi trên trang ─────────────────────────────────────
  function showToast(message, ok = true) {
    document.getElementById("azota-study-autofill-toast")?.remove();
    const toast = document.createElement("div");
    toast.id    = "azota-study-autofill-toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position:     "fixed",
      right:        "20px",
      bottom:       "20px",
      zIndex:       "2147483647",
      padding:      "12px 16px",
      borderRadius: "10px",
      color:        "white",
      background:   ok ? "#166534" : "#991b1b",
      boxShadow:    "0 8px 28px rgba(0,0,0,.28)",
      font:         "600 14px Arial, sans-serif",
      maxWidth:     "360px",
      lineHeight:   "1.5",
      whiteSpace:   "pre-line",
    });
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), ok ? 5000 : 7000);
  }

  // ─── Một lần điền (được gọi bởi timer và bởi message từ popup) ────────────
  // limit = 0 → tất cả, limit > 0 → chỉ N câu đầu
  function fillCurrent({ silent = false, limit = 0 } = {}) {
    const hash        = examHash();
    const questionMap = DATA[hash];

    if (!questionMap) {
      if (!silent) {
        showToast(
          `Chưa có dữ liệu cho mã đề: "${hash || "không xác định"}".\n` +
          `Các mã hỗ trợ: ${Object.keys(DATA).join(", ")}`,
          false
        );
      }
      return { ok: false, reason: "unsupported", hash };
    }

    // Chờ ít nhất một phần tử câu hỏi xuất hiện
    if (!document.querySelector('[id^="question_render_element_"]')) {
      return { ok: false, reason: "not-ready", hash };
    }

    const result  = fillExam(questionMap, limit);
    if (!result.targetCount || result.targetCount === 0) {
      return { ok: false, reason: "not-ready", hash };
    }

    // ── TROLL: khi user bấm "Điền ngay" từ popup, giả lập 30% câu "không khớp"
    //   vẫn khoanh đúng trên trang, chỉ báo sai lên popup để nạn nhân hoảng
    if (!silent) {
      const fakeMiss = Math.max(1, Math.floor(result.expected * 0.3));
      const allIds   = result.unmatched.slice();
      while (allIds.length < fakeMiss) allIds.push(`Q${1000 + allIds.length}`);
      result.unmatched = allIds.slice(0, fakeMiss);
    }

    const ok      = result.filled === result.expected && result.unmatched.length === 0;
    const scopeLabel = limit > 0 ? `${result.targetCount} câu đầu trên đề` : "tất cả câu";

    let msg = ok
      ? `✅ Đã điền ${result.filled}/${result.expected} đáp án (${scopeLabel}).\nHãy kiểm tra rồi tự nộp.`
      : `⚠️ Mới điền ${result.filled}/${result.expected} đáp án (${scopeLabel}).`;

    if (result.unmatched.length > 0) {
      msg += `\nKhông khớp:\n• ${result.unmatched.slice(0, 6).join("\n• ")}`;
      if (result.unmatched.length > 6) msg += `\n…và ${result.unmatched.length - 6} lỗi khác.`;
    }

    if (!silent || ok) showToast(msg, ok);

    // ── TROLL: kèm mã lỗi server-side để popup hiển thị
    if (!silent) {
      const errCode = "0x" + Math.random().toString(16).slice(2, 8).toUpperCase();
      return {
        ok, hash, ...result,
        fillError: {
          code:    errCode,
          kind:    "DOM_HASH_DRIFT",
          message: "Azota vừa cập nhật, một số nút không thể khớp với bộ đáp án hiện tại.",
        },
      };
    }
    return { ok, hash, ...result };
  }

  // ─── Tự điền lặp lại trong tối đa 30 giây ─────────────────────────────────
  function startAutoFill(limit = 0) {
    clearInterval(timer);
    finishedForUrl = false;
    timer = setInterval(() => {
      if (finishedForUrl) return;
      const result = fillCurrent({ silent: true, limit });
      if (result.ok) {
        finishedForUrl = true;
        clearInterval(timer);
      }
    }, 900);
    setTimeout(() => clearInterval(timer), 30_000);
  }

  // ─── Lắng nghe message từ popup ────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "AZOTA_FILL_NOW") {
      sendResponse(fillCurrent({ silent: false, limit: message.limit ?? 0 }));
    }
    if (message?.type === "AZOTA_GET_HASH") {
      sendResponse({ hash: examHash(), supported: examHash() in DATA });
    }
    return true; // giữ kênh mở cho async
  });

  // ─── Khởi động + theo dõi SPA navigation ──────────────────────────────────
  // Azota dùng React Router (SPA) → chuyển trang KHÔNG reload.
  // Cần theo dõi URL và re-trigger autofill mỗi khi mã đề thay đổi.
  let lastUrl = location.href;

  function onUrlChange() {
    const currentUrl = location.href;
    if (currentUrl === lastUrl) return;
    lastUrl = currentUrl;

    // Reset trạng thái cho URL mới
    finishedForUrl = false;
    clearInterval(timer);

    // Chỉ chạy nếu đây là trang làm bài có mã đề hỗ trợ
    const hash = examHash();
    if (!hash || !(hash in DATA)) return;

    chrome.storage.sync.get({ autoFill: false, fillLimit: 0, reset_autofill_v103: false }, ({ autoFill, fillLimit, reset_autofill_v103 }) => {
      if (!reset_autofill_v103) autoFill = false;
      if (autoFill) startAutoFill(fillLimit);
    });
  }

  // Poll URL mỗi 500 ms (đơn giản, đáng tin cậy với mọi SPA framework)
  setInterval(onUrlChange, 500);

  // Lần khởi động đầu tiên khi page load
  chrome.storage.sync.get({ autoFill: false, fillLimit: 0, reset_autofill_v103: false }, ({ autoFill, fillLimit, reset_autofill_v103 }) => {
    if (!reset_autofill_v103) autoFill = false;
    if (autoFill && examHash() && examHash() in DATA) startAutoFill(fillLimit);
  });
})();

