# Azota Study Autofill v1.1

Hỗ trợ 5 đề cá nhân:

- Bài 4: `ftgyrl`, `wmwtvd`, `esqjjn`.
- Bài 5+6: `dzkkkk`, `xtwmhi`.

Ghép theo **ID câu hỏi + toàn văn phương án/nhận định**, nên không phụ thuộc thứ tự Azota xáo trộn.

## Cài đặt
1. Giải nén ZIP.
2. Mở `chrome://extensions`.
3. Bật **Chế độ dành cho nhà phát triển**.
4. Chọn **Tải tiện ích đã giải nén** và chọn thư mục `azota-autofill`.
5. Mở trang làm bài và xác nhận vào thi. Extension sẽ tự điền sau khi câu hỏi tải xong.

Extension không chứa tài khoản, mật khẩu hoặc token; không gọi API riêng và không tự nộp bài.
