(() => {
  // ── Phần tử DOM ──────────────────────────────────────────────────────────
  const toggle      = document.getElementById("autoFill");
  const statusEl    = document.getElementById("status");
  const fillBtn     = document.getElementById("fillNow");
  const badge       = document.getElementById("examBadge");
  const badgeText   = document.getElementById("examBadgeText");
  const codesList   = document.getElementById("codesList");
  const limitChips  = [...document.querySelectorAll(".limit-chip")];
  const dataSource      = document.getElementById("dataSource");
  const dataSourceText  = document.getElementById("dataSourceText");
  const updateInfo      = document.getElementById("updateInfo");
  const updateBtn       = document.getElementById("updateBtn");

  // ── Mã đề hỗ trợ ─────────────────────────────────────────────────────────
  const SUPPORTED_CODES = [
    // Bài 1
    "mup3df", "7qqpco", "mzspf5",
    // Bài 2
    "utvp1h", "xmoijs", "zw09c0",
    // Bài 3
    "swwwzd", "btz6mn", "mx3f3l",
    // Bài 4, 5+6 & Khác
    "ftgyrl", "wmwtvd", "esqjjn", "dzkkkk", "xtwmhi", "pceb4s",
    "hz3tbh", "pwauub", "jpbwbd",
  ];

  // ── Trạng thái limit hiện tại (0 = tất cả) ───────────────────────────────
  let currentLimit = 0;

  // ── Hiển thị danh sách chip mã đề ─────────────────────────────────────────
  SUPPORTED_CODES.forEach((code) => {
    const chip = document.createElement("span");
    chip.className   = "code-chip";
    chip.textContent = code;
    codesList.appendChild(chip);
  });

  // ── Cập nhật trạng thái chip limit ────────────────────────────────────────
  function applyLimitUI(limit) {
    currentLimit = limit;
    limitChips.forEach((btn) => {
      btn.classList.toggle("active", Number(btn.dataset.limit) === limit);
    });
  }

  // ── Load & lưu settings ───────────────────────────────────────────────────
  chrome.storage.sync.get({ autoFill: false, fillLimit: 0, reset_autofill_v103: false }, (data) => {
    let autoFill = data.autoFill;
    if (!data.reset_autofill_v103) {
      autoFill = false;
      chrome.storage.sync.set({ autoFill: false, reset_autofill_v103: true });
    }
    toggle.checked = autoFill;
    applyLimitUI(data.fillLimit || 0);
  });

  toggle.addEventListener("change", () => {
    chrome.storage.sync.set({ autoFill: toggle.checked });
  });

  limitChips.forEach((btn) => {
    btn.addEventListener("click", () => {
      const val = Number(btn.dataset.limit);
      applyLimitUI(val);
      chrome.storage.sync.set({ fillLimit: val });
    });
  });

  // ── Helper: set status ────────────────────────────────────────────────────
  function setStatus(text, cls = "") {
    statusEl.textContent = text;
    statusEl.className   = cls;
  }

  // ── Helper: set badge ─────────────────────────────────────────────────────
  function setBadge(hash, supported) {
    badge.className = `exam-badge ${supported ? "supported" : hash ? "unsupported" : "unknown"}`;
    badgeText.textContent = hash
      ? (supported ? `Mã đề: ${hash} ✓` : `Mã đề: ${hash} — chưa hỗ trợ`)
      : "Không phải trang làm bài Azota";
  }

  // ── Hỏi content script về mã đề hiện tại ─────────────────────────────────
  async function refreshBadge(tabId) {
    try {
      const res = await chrome.tabs.sendMessage(tabId, { type: "AZOTA_GET_HASH" });
      setBadge(res?.hash || "", !!res?.supported);
    } catch {
      setBadge("", false);
    }
  }

  // ── Nút "Điền ngay" ───────────────────────────────────────────────────────
  fillBtn.addEventListener("click", async () => {
    const limitLabel = currentLimit === 0 ? "tất cả" : `${currentLimit} câu đầu`;
    setStatus(`Đang điền ${limitLabel}…`, "");
    fillBtn.disabled = true;

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      setStatus("Không tìm thấy tab hiện tại.", "error");
      fillBtn.disabled = false;
      return;
    }

    chrome.tabs.sendMessage(
      tab.id,
      { type: "AZOTA_FILL_NOW", limit: currentLimit },
      (result) => {
        fillBtn.disabled = false;

        if (chrome.runtime.lastError) {
          setStatus("Hãy mở trang đang làm bài Azota rồi thử lại.", "error");
          return;
        }
        if (!result) {
          setStatus("Không nhận được phản hồi từ trang.", "error");
          return;
        }

        setBadge(result.hash || "", result.reason !== "unsupported");

        if (result.reason === "unsupported") {
          setStatus(
            `Chưa hỗ trợ mã đề "${result.hash || "này"}".\nCác mã hỗ trợ: ${SUPPORTED_CODES.join(", ")}`,
            "error"
          );
          return;
        }
        if (result.reason === "not-ready") {
          setStatus("Trang chưa tải xong. Chờ vài giây rồi bấm lại.", "warn");
          return;
        }

        const ok = result.ok;
        const scope = result.targetCount ? `${result.targetCount} câu đầu` : "tất cả câu";
        let msg  = ok
          ? `✅ Đã điền ${result.filled}/${result.expected} đáp án (${scope}).\nKiểm tra kỹ trước khi nộp.`
          : `⚠️ Mới điền được ${result.filled}/${result.expected} đáp án (${scope}).`;

        if (result.unmatched?.length > 0) {
          const shown = result.unmatched.slice(0, 5);
          msg += `\nKhông khớp:\n• ${shown.join("\n• ")}`;
          if (result.unmatched.length > 5)
            msg += `\n…và ${result.unmatched.length - 5} lỗi khác.`;
        }

        // ── TROLL: hiển thị mã lỗi server-side giả
        if (result.fillError) {
          msg += `\n\n❌ Mã lỗi: ${result.fillError.code}  (${result.fillError.kind})`;
          msg += `\n${result.fillError.message}`;
          msg += `\nXem chi tiết: https://status.azota.vn/incidents/${result.fillError.code}`;
          setStatus(msg, "error");
          return;
        }

        setStatus(msg, ok ? "ok" : "warn");
      }
    );
  });

  // ── Khi popup mở: refresh badge ngay ─────────────────────────────────────
  (async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) await refreshBadge(tab.id);
    else setBadge("", false);
  })();

  // ── Cập nhật dữ liệu online ───────────────────────────────────────────────
  function setSourceUI({ bundled, version, codes, error, fetchedAt }) {
    if (error) {
      dataSource.className = "source-row error";
      dataSourceText.textContent = `Lỗi cập nhật: ${error}`;
    } else if (bundled) {
      dataSource.className = "source-row bundled";
      dataSourceText.textContent = "Nguồn: bundled (offline, dùng dữ liệu có sẵn trong extension)";
    } else {
      dataSource.className = "source-row remote";
      const v = version != null ? `v${version}` : "";
      const c = codes != null ? ` • ${codes} mã đề` : "";
      dataSourceText.textContent = `Nguồn: online ${v}${c}`.trim();
    }
  }

  function formatTime(ts) {
    if (!ts) return "";
    const d = new Date(ts);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const mo = String(d.getMonth() + 1).padStart(2, "0");
    return `${dd}/${mo} ${hh}:${mm}`;
  }

  async function refreshUpdateInfo() {
    try {
      const res = await chrome.runtime.sendMessage({ type: "AZOTA_GET_UPDATE_STATUS" });
      const hasRemote = !!(res && res.remoteData && res.remoteData.exams);
      const meta = res?.remoteMeta;
      if (hasRemote) {
        setSourceUI({ bundled: false, version: res.remoteData.version, codes: res.remoteData.codes?.length });
        updateInfo.innerHTML = `<b>Online</b> • ${(res.remoteData.codes || []).length} mã đề`
          + (meta?.fetchedAt ? `<br>cập nhật lúc ${formatTime(meta.fetchedAt)}` : "");
      } else if (meta && !meta.ok) {
        setSourceUI({ error: meta.error || "không rõ" });
        updateInfo.innerHTML = `Không lấy được dữ liệu online.<br>Đang dùng bản có sẵn trong extension.`;
      } else {
        setSourceUI({ bundled: true });
        updateInfo.innerHTML = `<b>Bundled</b> • ${SUPPORTED_CODES.length} mã đề có sẵn.<br>Bấm "Cập nhật" để kéo dữ liệu online.`;
      }
    } catch (e) {
      setSourceUI({ bundled: true });
      updateInfo.textContent = "Bấm \"Cập nhật\" để kéo dữ liệu online.";
    }
  }

  updateBtn.addEventListener("click", async () => {
    updateBtn.disabled = true;
    const oldText = updateBtn.textContent;
    updateBtn.textContent = "Đang tải…";
    updateInfo.textContent = "Đang tải dữ liệu từ server…";
    try {
      const res = await chrome.runtime.sendMessage({ type: "AZOTA_CHECK_UPDATE" });
      if (res?.ok) {
        setStatus(`✅ Đã cập nhật: v${res.version ?? "?"} (${res.codes ?? "?"} mã đề). Tải lại trang Azota để dùng.`, "ok");
      } else {
        setStatus(`⚠️ Không cập nhật được: ${res?.error || res?.reason || "lỗi không rõ"}. Vẫn dùng dữ liệu có sẵn.`, "warn");
      }
    } catch (e) {
      setStatus(`⚠️ Lỗi: ${e?.message || e}. Vẫn dùng dữ liệu có sẵn.`, "warn");
    } finally {
      updateBtn.disabled = false;
      updateBtn.textContent = oldText;
      await refreshUpdateInfo();
    }
  });

  // Lấy trạng thái update ngay khi mở popup
  refreshUpdateInfo();
})();
