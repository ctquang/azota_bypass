globalThis.AZOTA_ANSWER_DATA = {
  "ftgyrl": {
    "414977124": {
      "text": "mất, thêm hoặc thay thế một cặp nucleotide.",
      "type": "mc"
    },
    "414977125": {
      "text": "những cơ thể mang allele đột biến đã biểu hiện thành kiểu hình.",
      "type": "mc"
    },
    "414977126": {
      "text": "điều kiện môi trường và tổ hợp gene mang đột biến.",
      "type": "mc"
    },
    "414977127": {
      "text": "đột biến gene luôn gây hại cho sinh vật vì làm biến đổi cấu trúc của gene.",
      "type": "mc"
    },
    "414977128": {
      "text": "thay thế một cặp nucleotide.",
      "type": "mc"
    },
    "414977129": {
      "text": "A-T → G-C.",
      "type": "mc"
    },
    "414977130": {
      "text": "Đột biến gene có thể xảy ra ở cả tế bào sinh dưỡng và tế bào sinh dục.",
      "type": "mc"
    },
    "414977131": {
      "text": "Đột biến gene.",
      "type": "mc"
    },
    "414977132": {
      "text": "Đột biến điểm.",
      "type": "mc"
    },
    "414977133": {
      "text": "Thể đột biến.",
      "type": "mc"
    },
    "414977134": {
      "text": "Đột biến điểm.",
      "type": "mc"
    },
    "414977135": {
      "text": "Phần lớn đột biến điểm là dạng đột biến mất 1 cặp nucleotide.",
      "type": "mc"
    },
    "414977136": {
      "text": "Đột biến điểm là dạng đột biến liên quan đến 1 số cặp nucleotide trong gene.",
      "type": "mc"
    },
    "414977137": {
      "text": "Gene đột biến khi phát sinh chắc chắn được biểu hiện ngay ra kiểu hình.",
      "type": "mc"
    },
    "414977138": {
      "text": "có thể được phát tán trong quần thể nhờ quá trình giao phối.",
      "type": "mc"
    },
    "414977139": {
      "text": "A - T → A - 5BU → G - 5BU → G – C.",
      "type": "mc"
    },
    "414977140": {
      "text": "Thêm 1 cặp nucleotide A - T.",
      "type": "mc"
    },
    "414977141": {
      "text": "Mất 1 cặp nucleotide A - T.",
      "type": "mc"
    },
    "414977142": {
      "text": "2",
      "type": "mc"
    },
    "414977143": {
      "text": "2",
      "type": "mc"
    },
    "414977144": {
      "text": "Quá trình tự nhân đôi DNA không theo nguyên tắc bổ sung thì sẽ phát sinh đột biến gene.",
      "type": "mc"
    },
    "414977145": {
      "text": "Những cơ thể mang allele đột biến đều là thể đột biến.",
      "type": "mc"
    },
    "414977146": {
      "text": "Khi ở dạng dị hợp, đột biến gene trội cũng được gọi là thể đột biến.",
      "type": "mc"
    },
    "414977147": {
      "text": "3.",
      "type": "mc"
    },
    "414977148": {
      "text": "3.",
      "type": "mc"
    },
    "414977149": {
      "text": "aaBb, Aabb.",
      "type": "mc"
    },
    "414977150": {
      "text": "aaBB.",
      "type": "mc"
    },
    "414977151": {
      "text": "AaBbCc, aabbcc, aaBbCc.",
      "type": "mc"
    },
    "414977152": {
      "text": "Mất 1 cặp nuclêôtỉt loại A - T.",
      "type": "mc"
    },
    "414977153": {
      "text": "thêm 1 cặp G - C.",
      "type": "mc"
    },
    "414977154": {
      "text": "A = T= 599; G = C= 900",
      "type": "mc"
    },
    "414977155": {
      "text": "A = T = 799; G = C = 400",
      "type": "mc"
    },
    "414977156": {
      "text": "thay thế một cặp G-C bằng một cặp A-T.",
      "type": "mc"
    },
    "414977157": {
      "text": "2399.",
      "type": "mc"
    },
    "414977158": {
      "text": "72%.",
      "type": "mc"
    },
    "414977159": {
      "text": "Pro – Gly – Ser – Pro – Ala.",
      "type": "mc"
    },
    "414977160": {
      "text": "3’ GAG CCC TTT AAA 5’",
      "type": "mc"
    },
    "414977161": {
      "text": "3.",
      "type": "mc"
    },
    "414977162": {
      "text": "2.",
      "type": "mc"
    },
    "414977163": {
      "text": "3",
      "type": "mc"
    }
  },
  "wmwtvd": {
    "414977997": {
      "items": [
        {
          "text": "Đột biến thay thế một cặp nucleotide luôn dẫn đến kết thúc sớm quá trình dịch mã.",
          "value": "Sai"
        },
        {
          "text": "Đột biến gene tạo ra các allele mới làm phong phú vốn gene của quần thể.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến gene có thể có lợi, có hại hoặc trung tính đối với thể đột biến.",
          "value": "Đúng"
        },
        {
          "text": "Mức độ gây hại của allele đột biến phụ thuộc vào tổ hợp gene và điều kiện môi trường.",
          "value": "Đúng"
        }
      ],
      "type": "tf"
    },
    "414977998": {
      "items": [
        {
          "text": "Nếu đột biến thay thế một cặp nucleotide ở vị trí giữa gene thì có thể làm thay đổi toàn bộ các bộ ba từ vị trí xảy ra đột biến cho đến cuối gene.",
          "value": "Sai"
        },
        {
          "text": "Nếu đột biến mất cặp nucleotide thì allele a và allele A có chiều dài bằng nhau.",
          "value": "Sai"
        },
        {
          "text": "Allele a và allele A có số lượng nucleotide luôn bằng nhau.",
          "value": "Sai"
        },
        {
          "text": "Chuỗi polipeptide do allele a và chuỗi polipeptide do allele A quy định có thể có trình tự amino acid giống nhau.",
          "value": "Đúng"
        }
      ],
      "type": "tf"
    },
    "414977999": {
      "items": [
        {
          "text": "Vùng mã hóa trên mạch gốc của gene trên có 80 triplet.",
          "value": "Sai"
        },
        {
          "text": "Đột biến thay thế một cặp nucleotide C-G thành A-T xảy ra tại nucleotide thứ 12 tính từ đầu 3’ của đoạn mạch trên sẽ làm cho chuỗi polipeptide do gene quy định tổng hợp bị mất đi một amino acid so với chuỗi polipeptide bình thường.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến thay thế một cặp nucleotide bất kì xảy ra tại bộ ba thứ 82 trong đoạn gene trên luôn làm biến đổi thành phần amino acid của chuỗi polipeptide do gene quy định tổng hợp.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến thay thế một cặp nucleotide C - G thành G - C xảy ra tại nucleotide thứ 10 tính từ đầu 3’ không ảnh hưởng đến số lượng, thành phần và trình tự sắp xếp của các amino acid trong chuỗi polipeptide do gene quy định tổng hợp.",
          "value": "Sai"
        }
      ],
      "type": "tf"
    },
    "414978000": {
      "items": [
        {
          "text": "Tỉ lệ (A + T): (G+C) của allele b bằng tỉ lệ (G+ A): (T+C) của allele B.",
          "value": "Sai"
        },
        {
          "text": "Nếu allele b phát sinh do đột biến xảy ra ngay sau mã mở đầu thì chuỗi polypeptide do allele b quy định giống với chuỗi polypeptide do allele B quy định.",
          "value": "Sai"
        },
        {
          "text": "Nếu allele b phát sinh do đột biến xảy ra trong giảm phân thì allele b có thể di truyền cho đời sau.",
          "value": "Đúng"
        },
        {
          "text": "Nếu allele b phát sinh do đột biến thêm 1 cặp G - C thì allele b có 421 nucleotide loại G.",
          "value": "Đúng"
        }
      ],
      "type": "tf"
    },
    "414978001": {
      "items": [
        {
          "text": "Base hiếm có vị trí liên kết hydrogen bị thay đổi làm phát sinh đột biến mất cặp nucleotide trong quá trình nhân đôi DNA.",
          "value": "Sai"
        },
        {
          "text": "Tia phóng xạ có khảng năng gây ion hóa các phân tử vật chất nên có thể gây nên đột biến thay thế nucleotide.",
          "value": "Đúng"
        },
        {
          "text": "Hóa echất 5BU là chất đồng đẳng của thymine gây thay thế cặp A-T bằng cặp G-C.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến gene xảy ra có thể do tác động lí, hóa, sinh hoặc do sự rối loạn trao đổi chất xảy ra trong tế bào.",
          "value": "Đúng"
        }
      ],
      "type": "tf"
    },
    "414978002": {
      "items": [
        {
          "text": "Đột biến vô nghĩa thường làm mất chức năng của protein.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến gene đa số gây hại.",
          "value": "Đúng"
        },
        {
          "text": "Trong điều kiện nhân tạo, khi sử dụng tác nhân đột biến thì tần số đột biến sẽ được hạ xuống nhiều lần",
          "value": "Sai"
        },
        {
          "text": "Đột biến gene xảy ra ở trình tự intron thường gây hậu quả rất lớn.",
          "value": "Sai"
        }
      ],
      "type": "tf"
    },
    "414978003": {
      "items": [
        {
          "text": "Nếu không xảy ra đột biến, số amino acid trong chuỗi polypepetide hoàn chỉnh sẽ luôn có 2 amino acid.",
          "value": "Sai"
        },
        {
          "text": "Nếu xảy ra đột biến thay một cặp nucleotide bất kì, thì số amino acid trong chuỗi polypepetide hoàn chỉnh tối đa có 5 amino acid.",
          "value": "Đúng"
        },
        {
          "text": "Nếu xảy ra đột biến thêm một cặp nucleotide bất kì, mạch (II) làm khuôn, đầu (2) của mạch (II) là đầu 5’ thì tối đa chuỗi polypepetide hoàn chỉnh có 4 amino acid.",
          "value": "Đúng"
        },
        {
          "text": "Nếu xảy ra đột biến thêm một cặp nucleotide bất kì thì tối đa chuỗi polypepetide hoàn chỉnh có 10 amino acid.",
          "value": "Sai"
        }
      ],
      "type": "tf"
    }
  },
  "esqjjn": {
    "414978712": {
      "type": "short",
      "value": "5"
    },
    "414978713": {
      "type": "short",
      "value": "399"
    },
    "414978714": {
      "type": "short",
      "value": "2162"
    },
    "414978715": {
      "type": "short",
      "value": "3,45"
    },
    "414978716": {
      "type": "short",
      "value": "4"
    },
    "414978717": {
      "type": "short",
      "value": "1"
    }
  },
  "dzkkkk": {
    "414979554": {
      "type": "tf",
      "items": [
        {
          "text": "Nhiễm sắc thể được cấu tạo từ DNA và protein.",
          "value": "Đúng"
        },
        {
          "text": "Sợi cơ bản xoắn bậc hai tạo thành sợi siêu xoắn có đường kính 300 nm (sợi chromatid).",
          "value": "Sai"
        },
        {
          "text": "Chuỗi polynucleosome là sợi cơ bản, có đường kính (kích thước chiều ngang) 10 nm.",
          "value": "Đúng"
        },
        {
          "text": "Ở sinh vật nhân sơ và sinh vật nhân thực đều có cấu trúc nhiễm sắc thể.",
          "value": "Sai"
        }
      ]
    },
    "414979555": {
      "type": "tf",
      "items": [
        {
          "text": "Nhiễm sắc thể là vật chất di truyền ở cấp độ phân tử.",
          "value": "Sai"
        },
        {
          "text": "Ở các giao tử, số lượng nhiễm sắc thể giảm đi một nửa.",
          "value": "Đúng"
        },
        {
          "text": "Nhiễm sắc thể gồm hai loại: nhiễm sắc thể giới tính và nhiễm sắc thể thường.",
          "value": "Đúng"
        },
        {
          "text": "Nhiễm sắc thể thường và nhiễm sắc thể giới tính trong tế bào soma ở trạng thái lưỡng bội (2n) luôn tồn tại thành từng cặp tương đồng.",
          "value": "Sai"
        }
      ]
    },
    "414979556": {
      "type": "tf",
      "items": [
        {
          "text": "Lặp đoạn làm tăng số lượng bản sao của gene, tăng khả năng tạo đột biến gene.",
          "value": "Đúng"
        },
        {
          "text": "Tạo giống cây trồng bằng cách tạo đột biến chuyển đoạn lớn để loại bỏ một số gene có hại.",
          "value": "Sai"
        },
        {
          "text": "Thể đa bội cùng nguồn chẵn và đa bội khác nguồn có thể hình thành nên giống, loài mới.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến số lượng nhiễm sắc thể được dùng để xác định các vị trí của gene trên nhiễm sắc thể.",
          "value": "Sai"
        }
      ]
    },
    "414979557": {
      "type": "tf",
      "items": [
        {
          "text": "Đột biến lặp đoạn có thể dẫn đến lặp gene, tạo điều kiện cho đột biến gene, tạo ra các allele mới.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến lặp đoạn có thể làm cho 2 allele của 1 gene cùng nằm trên 1 NST.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến lặp đoạn làm tăng số lượng gene trên 1 NST.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến lặp đoạn luôn có lợi cho thể đột biến.",
          "value": "Sai"
        }
      ]
    },
    "414979558": {
      "type": "tf",
      "items": [
        {
          "text": "Thể đa bội có hàm lượng DNA trong nhân tế bào tăng lên gấp bội.",
          "value": "Đúng"
        },
        {
          "text": "Các thể đa bội đều không có khả năng sinh sản hữu tính.",
          "value": "Sai"
        },
        {
          "text": "Sử dụng consixin để ức chế quá trình hình thành thoi phân bào có thể gây đột biến đa bội ở thực vật.",
          "value": "Đúng"
        },
        {
          "text": "Sự không phân li của 1 nhiễm sắc thể trong nguyên phân của tế bào xôma ở một cơ thể luôn tạo ra thể ba.",
          "value": "Sai"
        }
      ]
    },
    "414979559": {
      "type": "tf",
      "items": [
        {
          "text": "Đột biến chuyển đoạn có thể không làm thay đổi số lượng và thành phần gene của một nhiễm sắc thể.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến cấu trúc nhiễm sắc thể chỉ xảy ra ở nhiễm sắc thể thường mà không xảy ra ở nhiễm sắc thể giới tính.",
          "value": "Sai"
        },
        {
          "text": "Đột biến mất đoạn không làm thay đổi số lượng gene trên nhiễm sắc thể",
          "value": "Sai"
        },
        {
          "text": "Đột biến đảo đoạn làm cho gene từ nhóm liên kết này chuyển sang nhóm liên kết khác.",
          "value": "Sai"
        }
      ]
    },
    "414979560": {
      "type": "tf",
      "items": [
        {
          "text": "Đột biến chuyển đoạn có thể không làm thay đổi số lượng và thành phần gene trên một nhiễm sắc thể.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến đảo đoạn làm cho gen từ nhóm gene liên kết này chuyển sang nhóm gene liên kết khác.",
          "value": "Sai"
        },
        {
          "text": "Đột biến lặp đoạn làm tăng chiều dài của nhiễm sắc thể.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến mất đoạn không làm thay đổi chiều dài của nhiễm sắc thể.",
          "value": "Sai"
        }
      ]
    },
    "414979561": {
      "type": "tf",
      "items": [
        {
          "text": "Dị đa bội là dạng đột biến làm tăng số nguyên lần bộ NST đơn bội của loài.",
          "value": "Sai"
        },
        {
          "text": "Thể đa bội lẻ thường không có khả năng sinh sản hữu tính bình thường.",
          "value": "Đúng"
        },
        {
          "text": "Thể tự đa bội có thể được hình thành do sự không phân ly của tất cả các NST trong lần nguyên phân đầu tiên của hợp tử.",
          "value": "Đúng"
        },
        {
          "text": "Thể dị đa bội có thể được hình thành nhờ lai xa kèm đa bội hóa.",
          "value": "Đúng"
        }
      ]
    },
    "414979562": {
      "type": "tf",
      "items": [
        {
          "text": "Thể dị đa bội thường gặp ở động vật, ít gặp ở thực vật.",
          "value": "Sai"
        },
        {
          "text": "Thể dị đa bội không thể sinh trưởng, phát triển và sinh sản hữu tính bình thường.",
          "value": "Sai"
        },
        {
          "text": "Thể dị đa bội có vai trò quan trọng trong quá trình hình thành loài mới.",
          "value": "Đúng"
        },
        {
          "text": "Thể dị đa bội được hình thành do lai xa kết hợp với đa bội hoá.",
          "value": "Đúng"
        }
      ]
    },
    "414979563": {
      "type": "tf",
      "items": [
        {
          "text": "Loài này có tối đa 42 loại kiểu gene.",
          "value": "Đúng"
        },
        {
          "text": "Ở loài này, các thể ba có tối đa 33 loại kiểu gene.",
          "value": "Đúng"
        },
        {
          "text": "Ở loài này, các cây mang kiểu hình lặn về 1 trong 3 tính trạng có tối đa 10 loại kiểu gene.",
          "value": "Sai"
        },
        {
          "text": "Ở loài này, các cây mang kiểu hình  trội về cả 3 tính trạng có tối đa 20 loại kiểu gene.",
          "value": "Đúng"
        }
      ]
    },
    "414979564": {
      "type": "tf",
      "items": [
        {
          "text": "Nếu A, B, d, e là các allele đột biến thì các thể đột biến về cả 4 gene có tối đa 4 loại kiểu gene.",
          "value": "Đúng"
        },
        {
          "text": "Nếu A, B, D, e là các allele đột biến thì các thể đột biến về cả 4 gene có tối đa 10 loại kiểu gene.",
          "value": "Sai"
        },
        {
          "text": "Nếu a, b, d, e là các allele đột biến thì các thể đột biến có tối đa 64 loại kiểu gene.",
          "value": "Sai"
        },
        {
          "text": "Nếu A, B, D, E là các allele đột biến thì các thể đột biến có tối đa 80 loại kiểu gene.",
          "value": "Đúng"
        }
      ]
    },
    "414979565": {
      "type": "tf",
      "items": [
        {
          "text": "Các giao tử được tạo ra có bộ NST là (n+1) và (n-1).",
          "value": "Đúng"
        },
        {
          "text": "Kết thúc quá trình giảm phân tạo ra 4 giao tử đột biến.",
          "value": "Đúng"
        },
        {
          "text": "Giao tử được tạo ra có thể có kiểu gene AB hoặc abDd.",
          "value": "Sai"
        },
        {
          "text": "Số loại giao tử tối đa được tạo ra là 4.",
          "value": "Sai"
        }
      ]
    },
    "414979566": {
      "type": "tf",
      "items": [
        {
          "text": "Lệch bội xảy ra trong nguyên phân ở tế bào sinh dưỡng làm cho một phần cơ thể mang đột biến lệch bội hình thành thể khảm.",
          "value": "Đúng"
        },
        {
          "text": "Hình ảnh này diễn tả cơ chế tạo thể lệch bội trong giảm phân.",
          "value": "Sai"
        },
        {
          "text": "Các thể lệch bội không bao giờ sống được do sự tăng hoặc giảm số lượng của một hoặc một vài cặp NST làm mất cân bằng toàn bộ hệ gen.",
          "value": "Sai"
        },
        {
          "text": "Trong chọn giống, có thể sử dụng đột biến lệch bội để đưa các NST mong muốn vào cơ thể khác.",
          "value": "Đúng"
        }
      ]
    },
    "414979567": {
      "type": "tf",
      "items": [
        {
          "text": "Cônsixin thường tác động vào pha S của chu kì tế bào.",
          "value": "Sai"
        },
        {
          "text": "Hóa chất cônsixin cản trở sự hình thành thoi vô sắc.",
          "value": "Đúng"
        },
        {
          "text": "Hình ảnh này diễn tả hiện tượng tự đa bội trong nguyên phân.",
          "value": "Đúng"
        },
        {
          "text": "Cơ chế hình thành là do bộ NST nhân đôi nhưng có thể thoi phân bào không hình thành nên NST không phân li trong tế bào soma là cơ chế duy nhất tạo ra thể đa bội.",
          "value": "Sai"
        }
      ]
    },
    "414979568": {
      "type": "tf",
      "items": [
        {
          "text": "Đột biến được biểu hiện ra kiểu hình dưới dạng thể khảm.",
          "value": "Sai"
        },
        {
          "text": "Tế bào A có thể sinh ra các tế bào con thiếu hoặc thừa nhiễm sắc thể.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến này di truyền qua sinh sản hữu tính.",
          "value": "Đúng"
        },
        {
          "text": "Tế bào A đang thực hiện quá trình nguyên phân.",
          "value": "Sai"
        }
      ]
    },
    "414979569": {
      "type": "tf",
      "items": [
        {
          "text": "Thể đột biến B có sức sống mạnh hơn thể đột biến A, nhưng yếu hơn thể đột biến C.",
          "value": "Sai"
        },
        {
          "text": "Kí hiệu của thể đột biến C là 2n + 2 + 2.",
          "value": "Đúng"
        },
        {
          "text": "Bộ NST lưỡng bội của loài này là 2n = 12.",
          "value": "Đúng"
        },
        {
          "text": "Thể đột biến A là thể tam bội, thể đột biến B là thể bốn.",
          "value": "Sai"
        }
      ]
    },
    "414979570": {
      "type": "tf",
      "items": [
        {
          "text": "Đột biến cấu trúc NST sẽ làm cho NST ngắn hơn bình thường (hình c)",
          "value": "Sai"
        },
        {
          "text": "Hình (b), (c) là đột biến cấu trúc nhiễm sắc thể",
          "value": "Sai"
        },
        {
          "text": "Trong tế bào sinh dưỡng NST tồn tại thành cặp tương đồng",
          "value": "Đúng"
        },
        {
          "text": "Đột biến số lượng nhiễm sắc thể có thể do sự kết hợp giữa giao tử bình thường và giao tử thừa 1 NST",
          "value": "Đúng"
        }
      ]
    },
    "414979571": {
      "type": "tf",
      "items": [
        {
          "text": "Cùng với các cá thể chuyển đoạn dị hợp tử, các cá thể đảo đoạn dị hợp tử khi giảm phân nếu trao đổi chéo xảy ra tại vùng đoạn đảo cũng sẽ bán bất thụ.",
          "value": "Đúng"
        },
        {
          "text": "Đột biến chuyển đoạn lớn thường gây chết và mất khả năng sinh sản.",
          "value": "Đúng"
        },
        {
          "text": "Nếu đoạn đảo trong đột biến đảo đoạn NST rơi vào các gene quan trọng thì sẽ ảnh hưởng tới sức sống và khả năng sinh sản của cá thể.",
          "value": "Đúng"
        },
        {
          "text": "Lặp đoạn có ý nghĩa đối với tiến hóa và tạo ra các vật chất di truyền bổ sung, nhờ đột biến và chọn lọc tự nhiên có thể hình thành các gene mới.",
          "value": "Đúng"
        }
      ]
    }
  },
  "xtwmhi": {
    "414979838": {
      "type": "short",
      "value": "3"
    },
    "414979839": {
      "type": "short",
      "value": "4"
    },
    "414979840": {
      "type": "short",
      "value": "2"
    },
    "414979841": {
      "type": "short",
      "value": "108"
    },
    "414979842": {
      "type": "short",
      "value": "12"
    }
  },
  "mup3df": {
    "408647248": {
      "type": "mc",
      "text": "DNA là vật chất di truyền và lưu trữ thông tin nhờ có cấu trúc hai mạch xoắn kép và trình tự nucleotide đặc hiệu."
    },
    "408647249": {
      "type": "mc",
      "text": "DNA có thể tự tái bản và quá trình tái bản sử dụng năng lượng ATP để thực hiện các bước tháo xoắn, tổng hợp mạch mới."
    },
    "408647250": {
      "type": "mc",
      "text": "Vận chuyển axit amin đến ribosome trong quá trình dịch mã."
    },
    "408647251": {
      "type": "mc",
      "text": "Các base nitơ được gắn với ribose tạo nên độ bền vững cao."
    },
    "408647252": {
      "type": "mc",
      "text": "Quá trình tái bản không cần năng lượng vì xảy ra tự nhiên."
    },
    "408647253": {
      "type": "mc",
      "text": "Nguyên tắc đặc hiệu enzyme."
    },
    "408647254": {
      "type": "mc",
      "text": "Enzyme ligase."
    },
    "408647255": {
      "type": "mc",
      "text": "Có cấu trúc hai mạch xoắn kép, đường kính vòng xoắn 10Å."
    },
    "408647256": {
      "type": "mc",
      "text": "Nhân đôi DNA"
    },
    "408647257": {
      "type": "mc",
      "text": "Liên kết với protein histon để tạo nên NST"
    },
    "408647258": {
      "type": "mc",
      "text": "Được phân chia không đều cho các tế bào con khi phân bào"
    },
    "408647259": {
      "type": "mc",
      "text": "Sơ đồ II"
    },
    "408647260": {
      "type": "mc",
      "text": "Enzyme lygase"
    },
    "408647261": {
      "type": "mc",
      "text": "Liên kết cộng hoá trị"
    },
    "408647262": {
      "type": "mc",
      "text": "Hai mạch mới được tổng hợp gián đoạn"
    },
    "408647263": {
      "type": "mc",
      "text": "RNA mạch đơn"
    },
    "408647264": {
      "type": "mc",
      "text": "Trong quá trình nhân đôi DNA, enzyme nối ligase chỉ tác động lên một trong hai mạch đơn mới được tổng hợp từ một phân tử DNA mẹ"
    },
    "408647265": {
      "type": "mc",
      "text": "5"
    },
    "408647266": {
      "type": "mc",
      "text": "Enzyme DNA polymerase làm nhiệm vụ tháo xoắn phân tử DNA và kéo dài mạch mới"
    },
    "408647267": {
      "type": "mc",
      "text": "Tổng hợp mạch mới theo nguyên tắc bổ sung với mạch khuôn của DNA"
    },
    "408647268": {
      "type": "mc",
      "text": "Nhân đôi DNA"
    },
    "408647269": {
      "type": "mc",
      "text": "1/64"
    },
    "408647270": {
      "type": "mc",
      "text": "Enzyme DNA polymerase tổng hợp và kéo dài mạch mới theo chiều 3’ → 5’"
    },
    "408647271": {
      "type": "mc",
      "text": "Do 2 mạch khuôn có cấu trúc ngược chiều nhưng enzyme DNA polymerase chỉ xúc tác tổng hợp mạch mới theo chiều 5’ → 3’"
    },
    "408647272": {
      "type": "tf",
      "items": [
        {
          "text": "Tính đa dạng của DNA là nhờ vào số lượng, thành phần và trật tự sắp xếp các nucleotide.",
          "value": "Đúng"
        },
        {
          "text": "Nếu tỉ lệ (A+T)/(G+C) càng nhỏ thì tính bền vững của DNA càng cao",
          "value": "Đúng"
        },
        {
          "text": "DNA là đại phân tử có cấu trúc đa phân, đơn phân là nucleotide.→ Đáp án đúng: a, b, d (phát biểu c sai – phải là tính bền vững càng cao nếu tỉ lệ này nhỏ)",
          "value": "Đúng"
        },
        {
          "text": "DNA của tất cả các loài đều có 4 loại nucleotide, nhưng đặc trưng bởi trình tự riêng.",
          "value": "Đúng"
        }
      ]
    },
    "408647273": {
      "type": "tf",
      "items": [
        {
          "text": "Trong quá trình nhân đôi DNA, cần sử dụng 4 loại nucleotide làm nguyên liệu.",
          "value": "Đúng"
        },
        {
          "text": "Các nhà nghiên cứu thấy rằng, khi DNA của sinh vật nhân thực được ngắn dần đến một giá trị nhất định thì tế bào sẽ đi vào con đường tự chết.",
          "value": "Đúng"
        },
        {
          "text": "Trong quá trình nhân đôi DNA, ngoài các loại enzyme tháo xoắn và các loại enzyme DNA polymerase thì cần phải có enzyme RNA polymerase và ligase.",
          "value": "Đúng"
        },
        {
          "text": "Các tế bào vi khuẩn thì vẫn có thể phân bào mãi mãi mà tế bào không tự chết giống như tế bào nhân thực.",
          "value": "Đúng"
        }
      ]
    },
    "408647274": {
      "type": "tf",
      "items": [
        {
          "text": "Ở mỗi phân tử DNA con, luôn có một mạch đơn được tổng hợp liên tục và một mạch được tổng hợp gián đoạn.",
          "value": "Sai"
        },
        {
          "text": "Đây là quá trình tái bản DNA ở sinh vật nhân sơ.",
          "value": "Sai"
        },
        {
          "text": "Mạch polynucleotide mới luôn được kéo dài theo chiều 5’ – 3’.",
          "value": "Đúng"
        },
        {
          "text": "Hai mạch polynucleotide mới được tổng hợp có trình tự nucleotide giống nhau.",
          "value": "Sai"
        }
      ]
    },
    "408647275": {
      "type": "tf",
      "items": [
        {
          "text": "[c] là loại enzyme xúc tác theo chiều 3’-5’ trên mỗi mạch khuôn của gene.",
          "value": "Đúng"
        },
        {
          "text": "[a] là enzyme tháo xoắn và phá vỡ liên kết hydrogene.",
          "value": "Đúng"
        },
        {
          "text": "[b] được hình thành nhờ enzyme RNA polymerase.",
          "value": "Đúng"
        },
        {
          "text": "Mạch khuôn 4-1 có chiều 5’-3’thì mạch mới tổng hợp ngược lại và theo chiều 5’-3’. (Lưu ý: câu nào ko có hình thì xem hình trong bài 2 sinh 10 – số câu ko trùng nhưng nội dung giống)",
          "value": "Đúng"
        }
      ]
    }
  },
  "7qqpco": {
    "413128386": {
      "type": "tf",
      "items": [
        {
          "text": "Ở hầu hết sinh vật, DNA là vật chất di truyền, mỗi phân tử DNA được cấu trúc gồm 2 chuỗi polynucleotide",
          "value": "Đúng"
        },
        {
          "text": "Mỗi mạch polynucleotide luôn có số lượng A = T và G = C",
          "value": "Sai"
        },
        {
          "text": "Các nucleotide trên hai mạch đơn của DNA liên kết với nhau bằng liên kết cộng hóa trị theo nguyên tắc bổ sung.",
          "value": "Sai"
        },
        {
          "text": "DNA cấu tạo theo nguyên tắc đa phân, đơn phân là các nucleotide.",
          "value": "Đúng"
        }
      ]
    },
    "413128387": {
      "type": "tf",
      "items": [
        {
          "text": "Gene phân mảnh có ở sinh vật nhân thực và một số ít vi sinh vật cổ.",
          "value": "Đúng"
        },
        {
          "text": "Gene phân mảnh là gene có vùng mã hóa gồm các trình tự được dịch mã (exon) xen kẽ các đoạn không được dịch mã (intron).",
          "value": "Đúng"
        },
        {
          "text": "Dựa vào cấu trúc vùng mã hóa, các gene được chia thành gene không phân mảnh và gene phân mảnh.",
          "value": "Đúng"
        },
        {
          "text": "Một gene có cấu trúc gồm vùng điều hòa, vùng mã hóa và vùng kết thúc.",
          "value": "Đúng"
        }
      ]
    },
    "413128388": {
      "type": "tf",
      "items": [
        {
          "text": "Thực hiện theo nguyên tắc bán bảo toàn, đó là mỗi DNA con có một mạch từ DNA mẹ, một mạch mới tổng hợp.",
          "value": "Đúng"
        },
        {
          "text": "Một mạch được tổng hợp gián đoạn tạo ra các phân đoạn Okazaki, sau đó enzyme DNA ligase xúc tác nối các phân đoạn này hình thành mạch dẫn đầu.",
          "value": "Sai"
        },
        {
          "text": "Các mạch mới được tổng hợp theo chiều 5' - 3' nhờ sự xúc tác của enzyme DNA polymerase.",
          "value": "Đúng"
        },
        {
          "text": "Một mạch được tổng hợp liên tục được gọi là mạch ra chậm.",
          "value": "Sai"
        }
      ]
    },
    "413128389": {
      "type": "tf",
      "items": [
        {
          "text": "Phân tử DNA của Chủng II có số liên kết hidrogen ít hơn phân tử DNA của chủng IV.",
          "value": "Đúng"
        },
        {
          "text": "Phân tử DNA của chủng IV có nhiệt độ nóng chảy cao nhất.",
          "value": "Sai"
        },
        {
          "text": "Chủng I và chủng IV có chiều dài phân tử bằng nhau.",
          "value": "Đúng"
        },
        {
          "text": "Tổng số nucleotide của chủng I nhiều hơn chủng II.",
          "value": "Sai"
        }
      ]
    },
    "413128390": {
      "type": "tf",
      "items": [
        {
          "text": "Xét về tính bền của vật chất di truyền khi tăng dần nhiệt độ thì loài I> II> III",
          "value": "Đúng"
        },
        {
          "text": "Vật chất di truyền ở loài IV và loài V là RNA, nhưng ở loài IV RNA có 2 mạch, còn ở loài V RNA có 1 mạch.",
          "value": "Đúng"
        },
        {
          "text": "Xét theo mức độ tiến hóa về vật chất di truyền thì loài I >II > III > V",
          "value": "Sai"
        },
        {
          "text": "Vật chất di truyền ở loài III có cấu trúc DNA hai mạch vì A = T, G = C.",
          "value": "Sai"
        }
      ]
    },
    "413128391": {
      "type": "tf",
      "items": [
        {
          "text": "Ở sinh vật nhân thực, sự nhân đôi DNA xảy ra ở nhiều điểm trong mỗi phân tử DNA tạo ra nhiều đơn vị nhân đôi và do nhiều loại enzyme tham gia.",
          "value": "Đúng"
        },
        {
          "text": "DNA của sinh vật nhân sơ có cấu tạo mạch vòng, DNA của sinh vật nhân thực có cấu tạo mạch thẳng.",
          "value": "Đúng"
        },
        {
          "text": "Hình 1 diễn tả quá trình nhân đôi DNA của sinh vật nhân thực và hình 2 diễn tả quá trình nhân đôi DNA của sinh vật nhân sơ.",
          "value": "Sai"
        },
        {
          "text": "Quá trình nhân đôi DNA của sinh vật nhân thực và sinh vật nhân sơ đều chỉ tạo một đơn vị tái bản.",
          "value": "Sai"
        }
      ]
    },
    "413128392": {
      "type": "tf",
      "items": [
        {
          "text": "Nếu một vi khuẩn E. coli được nuôi với các điều kiện thí nghiệm như trên thì luôn có hai mạch DNA chứa N15 ở mỗi thế hệ.",
          "value": "Đúng"
        },
        {
          "text": "Ở thế hệ thứ 4, tỉ lệ DNA ở vị trí Y không thay đổi so với thế hệ thứ 3.",
          "value": "Sai"
        },
        {
          "text": "Thí nghiệm trên đã kiểm chứng quá trình nhân đôi DNA theo nguyên tắc bán bảo toàn.",
          "value": "Đúng"
        },
        {
          "text": "Ở thế hệ thứ 5, tỉ lệ DNA ở vị trí Y so với DNA ở vị trí Z là 215 .",
          "value": "Sai"
        }
      ]
    },
    "413128393": {
      "type": "tf",
      "items": [
        {
          "text": "Gene A có số liên kết hydrogen ít hơn hơn gene a",
          "value": "Sai"
        },
        {
          "text": "Gene A có chiều dài lớn hơn gene a.",
          "value": "Đúng"
        },
        {
          "text": "Gene a có A = T = 360; G = X = 540.",
          "value": "Sai"
        },
        {
          "text": "Gene A có G = X = 538; A = T = 362.",
          "value": "Đúng"
        }
      ]
    },
    "413128394": {
      "type": "tf",
      "items": [
        {
          "text": "Số liên kết hydrogen của gene D là 3450.",
          "value": "Sai"
        },
        {
          "text": "Trên mạch 1 của gene D có GC =23",
          "value": "Sai"
        },
        {
          "text": "Trên mạch 2 của gene D có T = 2A.",
          "value": "Đúng"
        },
        {
          "text": "Gene D có chiều dài 510 nm.",
          "value": "Đúng"
        }
      ]
    },
    "413128395": {
      "type": "tf",
      "items": [
        {
          "text": "Sự thay đổi số lượng, trật tự sắp xếp các các nucleotide trên chuỗi polynucleotide dẫn đến sự thay đổi thông tin di truyền, tạo nên biến dị ở sinh vật",
          "value": "Đúng"
        },
        {
          "text": "Các nucleotide trên hai mạch đơn của DNA liên kết với nhau bằng các liên kết hydrogen, đây là các liên kết bền vững, khó bị bẻ gãy, do đó đảm bảo tính bền vững của DNA",
          "value": "Sai"
        },
        {
          "text": "Tất cả các thay đổi trong cấu trúc của DNA đều cung cấp nguyên liệu cho tiến hóa",
          "value": "Sai"
        },
        {
          "text": "DNA có khả năng thay đổi thông tin di truyền thông qua quá trình đột biến",
          "value": "Đúng"
        }
      ]
    },
    "413128396": {
      "type": "tf",
      "items": [
        {
          "text": "Tính theo chiều tháo xoắn, ở mạch khuôn có chiều 3’ - 5’ thì mạch mới được tổng hợp gián đoạn.",
          "value": "Sai"
        },
        {
          "text": "Sự nhân đôi của DNA ti thể diễn ra độc lập với sự nhân đôi của DNA trong nhân tế bào.",
          "value": "Đúng"
        },
        {
          "text": "Enzyme DNA-polimerase làm nhiệm vụ tháo xoắn phân tử DNA và kéo dài mạch mới.",
          "value": "Sai"
        },
        {
          "text": "Trên mỗi phân tử DNA của sinh vật nhân sơ chỉ có một điểm khởi đầu nhân đôi DNA.",
          "value": "Đúng"
        }
      ]
    }
  },
  "mzspf5": {
    "407995432": {
      "type": "short",
      "value": "10"
    },
    "407995433": {
      "type": "short",
      "value": "3"
    },
    "407995434": {
      "type": "short",
      "value": "2"
    },
    "407995435": {
      "type": "short",
      "value": "40"
    },
    "407995436": {
      "type": "short",
      "value": "39"
    },
    "407995437": {
      "type": "short",
      "value": "180"
    }
  },
  "utvp1h": {
    "413129259": {
      "type": "mc",
      "text": "tRNA"
    },
    "413129260": {
      "type": "mc",
      "text": "tRNA là một polynucleotide cuộn lại ở một đầu, có đoạn các cặp base liên kết theo nguyên tắc bổ sung, có đoạn tạo nên các thùy tròn, một đầu mang amino acid đặc hiệu, và một thùy tròn mang bộ ba đối mã (anticodon)."
    },
    "413129261": {
      "type": "mc",
      "text": "Phân giải protein."
    },
    "413129262": {
      "type": "mc",
      "text": "mRNA có cấu trúc mạch đơn, thẳng, gồm 4 loại đơn phân A, U, G, C"
    },
    "413129263": {
      "type": "mc",
      "text": "Adenine, Cytosine, Uracil, Guanine."
    },
    "413129264": {
      "type": "mc",
      "text": "rRNA có cấu trúc bền vững, tuổi thọ cao hơn."
    },
    "413129265": {
      "type": "mc",
      "text": "5’ CAU 3’."
    },
    "413129266": {
      "type": "mc",
      "text": "RNA"
    },
    "413129267": {
      "type": "mc",
      "text": "Mạch mã gốc"
    },
    "413129268": {
      "type": "mc",
      "text": "A trên mạch gốc liên kết với T của môi trường"
    },
    "413129269": {
      "type": "mc",
      "text": "2"
    },
    "413129270": {
      "type": "mc",
      "text": "Xoắn lại với mạch bổ sung của nó trên DNA"
    },
    "413129271": {
      "type": "mc",
      "text": "(2), (3)"
    },
    "413129272": {
      "type": "mc",
      "text": "(2) → (1) → (3) → (4)"
    },
    "413129273": {
      "type": "mc",
      "text": "RNA polymerase trượt dọc theo gene, tổng hợp mạch mRNA bổ sung với khuôn theo nguyên tắc bổ sung (A bắt đôi với U, T bắt đối với A, G bắt đối với X và ngược lại) theo chiều từ 5’ đến 3’trên mạch gốc."
    },
    "413129274": {
      "type": "mc",
      "text": "Việc lắp ghép các đơn phân được thực hiện trên cơ sở nguyên tắc bổ sung."
    },
    "413129275": {
      "type": "mc",
      "text": "5’…UUUAAXUCG…3’"
    },
    "413129276": {
      "type": "mc",
      "text": "5’AGCUUAGCA3’"
    },
    "413129277": {
      "type": "mc",
      "text": "22,5% T, 22,5% A, 27,5% G, 27,5% C."
    },
    "413129278": {
      "type": "mc",
      "text": "A = T = 250 và G = C = 350"
    },
    "413129279": {
      "type": "mc",
      "text": "Tạo ra chuỗi polypeptide mới."
    },
    "413129280": {
      "type": "mc",
      "text": "Bắt đầu bằng amino acid Met."
    },
    "413129281": {
      "type": "mc",
      "text": "Tăng hiệu suất tổng hợp protein."
    },
    "413129282": {
      "type": "mc",
      "text": "5’ TGG – CTT – CCA – AAC 3’"
    },
    "413129283": {
      "type": "mc",
      "text": "Ba loại G, A, U."
    },
    "413129284": {
      "type": "mc",
      "text": "3’ UGCCGGUUC 5’."
    },
    "413129285": {
      "type": "mc",
      "text": "(3) → (1) → (2) → (4) → (6) → (5)."
    },
    "413129286": {
      "type": "mc",
      "text": "Arginine - Serine - Arginine - Serine"
    },
    "413129287": {
      "type": "mc",
      "text": "Trình tự các nucleotide ở các axit nucleic mã hóa amino acid"
    },
    "413129288": {
      "type": "mc",
      "text": "Mã di truyền đặc trưng cho từng loài"
    },
    "413129289": {
      "type": "mc",
      "text": "Một bộ ba mã hoá chỉ mã hoá cho một loại amino acid."
    },
    "413129290": {
      "type": "mc",
      "text": "3’GUA5’, 5’UGG3’"
    },
    "413129291": {
      "type": "mc",
      "text": "Tính phổ biến"
    },
    "413129292": {
      "type": "mc",
      "text": "tất cả các loài đều có chung một bộ mã di truyền, trừ một vài ngoại lệ."
    },
    "413129293": {
      "type": "mc",
      "text": "Mã di truyền mang tính riêng biệt, mỗi loài sinh vật có một bộ mã di truyền riêng"
    },
    "413129294": {
      "type": "mc",
      "text": "Nấm."
    },
    "413129295": {
      "type": "mc",
      "text": "G = C = 240, A = T = 360."
    },
    "413129296": {
      "type": "mc",
      "text": "A = 103, U = 772, G = 356, C = 260"
    },
    "413129297": {
      "type": "mc",
      "text": "DNA bổ sung (cDNA) được cấu tạo từ 4 loại nu là A, U, G, C."
    },
    "413129298": {
      "type": "mc",
      "text": "Kết thúc quá trình trên tạo ra phân tử mRNA có chiều 3’ 🡪 5’."
    },
    "413129299": {
      "type": "mc",
      "text": "Amino acid tự do"
    }
  },
  "xmoijs": {
    "407974515": {
      "type": "tf",
      "items": [
        {
          "text": "rRNA có chức năng vận chuyển một loại amino acid tới ribosome khi dịch mã.",
          "value": "Sai"
        },
        {
          "text": "RNA được cấu tạo từ các loại nucleotide: Adenine (A), Uracil (U), Guanine (G) và Cytosine (C).",
          "value": "Đúng"
        },
        {
          "text": "Cả ba loại RNA (mRNA, tRNA, rRNA) có cấu trúc mạch đơn polynucleotide và đều tham gia vào quá trình dịch mã.",
          "value": "Đúng"
        },
        {
          "text": "rRNA có chức năng trung gian trung gian truyền thông tin di truyền từ gene đến protein.",
          "value": "Sai"
        }
      ]
    },
    "407974516": {
      "type": "tf",
      "items": [
        {
          "text": "Trong quá trình này, enzyme RNA polymerase bám vào vùng khởi động của gene và di chuyển trên gene.",
          "value": "Đúng"
        },
        {
          "text": "Ở sinh vật nhân thực, kết thúc phiên mã tạo ra mRNA có thể được dịch mã ngay.",
          "value": "Sai"
        },
        {
          "text": "Enzyme RNA polymerase trượt dọc theo mạch mã gốc trên gene theo chiều 3’ – 5’, để tổng hợp RNA có chiều 5’ → 3.",
          "value": "Đúng"
        },
        {
          "text": "Ở sinh vật nhân sơ, kết thúc phiên mã tạo ra tiền mRNA; tiền mRNA được xử lí gắn mũ ở đầu 5’, sau đó cắt bỏ intron, nối các exon và tổng hợp đuôi poly A ở đầu 3, tạo ra mRNA trưởng thành.",
          "value": "Sai"
        }
      ]
    },
    "407974517": {
      "type": "tf",
      "items": [
        {
          "text": "UCU chỉ mã hóa cho Ser (amino acid Serin) cho thấy mã di truyền có tính phổ biến.",
          "value": "Sai"
        },
        {
          "text": "Pro (amino acid Prolin) có thể được mã hóa bởi nhiều bộ ba: CCU, CCC, CCA, CCG cho thấy mã di truyền có tính đặc hiệu.",
          "value": "Đúng"
        },
        {
          "text": "Ba bộ ba: UGG, UAG và UGA là mã kết thúc.",
          "value": "Sai"
        },
        {
          "text": "Mã di truyền là mã bộ ba: ba nucleotide (một codon) liền nhau theo chiều 5' → 3' trên mRNA mã hoá một amino acid; mã di truyền được đọc kế tiếp, không gối nhau.",
          "value": "Đúng"
        }
      ]
    },
    "407974518": {
      "type": "tf",
      "items": [
        {
          "text": "Hình ảnh trên mô tả quá trình dịch mã đối với sinh vật nhân thực.",
          "value": "Sai"
        },
        {
          "text": "Giai đoạn kết thúc: Ribsome dịch chuyển đến bộ ba kết thúc trên mRNA, tRNA được giải phóng, hai tiểu phần ribosome tách nhau. Amino acid mở đầu được cắt khỏi chuỗi polypeptide mới được tổng hợp.",
          "value": "Đúng"
        },
        {
          "text": "Giai đoạn mở đầu: tRNA-fMet bắt cặp với bộ ba mở đầu AUG trên mRNA có bộ ba đối mã là UAC.",
          "value": "Đúng"
        },
        {
          "text": "Giai đoạn kéo dài: sau khi hai amino acid hình thành liên kết peptide thì Ribosome tiếp tục di chuyển qua một bộ ba về hướng đầu 5’ của mRNA.",
          "value": "Sai"
        }
      ]
    },
    "407974519": {
      "type": "tf",
      "items": [
        {
          "text": "RNA polymerase chỉ trượt dọc trên một mạch DNA làm khuôn theo chiều 3’→5’.",
          "value": "Đúng"
        },
        {
          "text": "DNA polymerase xúc tác kéo dài chuỗi polynucleotide theo cả hai chiều còn RNA polymerase chỉ xúc tác kéo dài chuỗi theo 1 chiều",
          "value": "Sai"
        },
        {
          "text": "RNA polymerase vừa có khả năng tháo xoắn một đoạn DNA, vừa có khả năng xúc tác kéo dài chuỗi polynucleotide.",
          "value": "Đúng"
        },
        {
          "text": "DNA polymerase có khả năng bẻ gãy các liên kết hidro giữa hai mạch đơn còn RNA polymerase thì không.",
          "value": "Sai"
        }
      ]
    },
    "407974520": {
      "type": "tf",
      "items": [
        {
          "text": "Ở sinh vật nhân thực, quá trình phiên mã diễn ra trong tế bào chất và quá trình dịch mã diễn ra trong nhân.",
          "value": "Sai"
        },
        {
          "text": "Trong các tế bào nhân sơ, không có màng ngăn nhân, ngay khi đầu 5’ của mRNA ló ra ngoài vị trí tổng hợp của RNA polymerase thì ribosome sẽ tiếp cận và bắt đầu quá trình dịch mã. Quá trình phiên mã và dịch mã diễn ra đồng thời ở sinh vật nhân sơ.",
          "value": "Đúng"
        },
        {
          "text": "Quá trình tổng hợp RNA ở sinh vật nhân sơ và sinh vật nhân thực luôn diễn ra theo hướng nhất định, luôn bắt đầu từ đầu 5’ và kết thúc với nucleotide ở đầu 3’.",
          "value": "Đúng"
        },
        {
          "text": "Ở tế bào nhân thực, mRNA sau phiên mã được trực tiếp làm khuôn để tổng hợp protein. Ở tế bào nhân sơ, mRNA sau phiên mã phải được cắt bỏ các intron nối các exon lại với nhau thành mRNA trưởng thành.",
          "value": "Sai"
        }
      ]
    },
    "407974521": {
      "type": "tf",
      "items": [
        {
          "text": "Quá trình phiên mã ở sinh vật nhân sơ thì ngược lại, mRNA sau phiên mã được trực tiếp dùng làm khuôn để tổng hợp protein.",
          "value": "Đúng"
        },
        {
          "text": "Số loại mRNA có thể tạo ra là 6.",
          "value": "Sai"
        },
        {
          "text": "Một mRNA sơ khai được xử lý theo nhiều cách khác nhau để tạo ra nhiều loại mRNA khác nhau, kết quả là tạo ra nhiều loại protein khác nhau từ một trình tự DNA.",
          "value": "Đúng"
        },
        {
          "text": "Sự cắt bỏ intron, nối exon diễn ra trong tế bào chất.",
          "value": "Sai"
        }
      ]
    },
    "407974522": {
      "type": "tf",
      "items": [
        {
          "text": "Dịch mã diễn ra cùng thời điểm với quá trình phiên mã.",
          "value": "Sai"
        },
        {
          "text": "Trong quá trình dịch mã, tRNA đóng vai trò như “người phiên dịch”.",
          "value": "Đúng"
        },
        {
          "text": "Ribosome di chuyển trên mRNA theo chiều từ 5’ - 3'.",
          "value": "Đúng"
        },
        {
          "text": "Diễn ra theo nguyên tắc bổ sung (A-T, G-C và ngược lại).",
          "value": "Sai"
        }
      ]
    },
    "407974523": {
      "type": "tf",
      "items": [
        {
          "text": "Mạch I làm khuôn, chiều phiên mã từ (1) sang (2) sẽ cho một chuỗi polypeptide hoàn chỉnh dài 1 amino acid.",
          "value": "Sai"
        },
        {
          "text": "Để thu được chuỗi polypeptide dài nhất, thì mạch I là mạch bổ sung, chiều phiên mã trên mạch I là từ (1) sang (2).",
          "value": "Sai"
        },
        {
          "text": "Để thu được chuỗi polypeptide dài 3 amino acid, thì mạch I là mạch bổ sung, đầu (1) trên mạch này là đầu 5’",
          "value": "Đúng"
        },
        {
          "text": "Mạch I làm khuôn, chiều phiên mã từ (2) sang (1) thì trên 8 bộ ba trên mRNA không tham gia dịch mã.",
          "value": "Đúng"
        }
      ]
    },
    "407974524": {
      "type": "tf",
      "items": [
        {
          "text": "Mỗi bộ ba chỉ mã hóa cho một loại amino acid (trừ các bộ ba kết thúc).",
          "value": "Đúng"
        },
        {
          "text": "Có thể đọc mã di truyền ở bất cứ điểm nào trên mRNA chỉ cần theo chiều 5' – 3'.",
          "value": "Sai"
        },
        {
          "text": "Số loại amino acid nhiều hơn số bộ ba mã hóa.",
          "value": "Sai"
        },
        {
          "text": "Mã mở đầu ở sinh vật nhân thực mã hóa cho amino acid methyonine.",
          "value": "Đúng"
        }
      ]
    }
  },
  "zw09c0": {
    "413129448": {
      "type": "short",
      "value": "3"
    },
    "413129449": {
      "type": "short",
      "value": "1"
    },
    "413129450": {
      "type": "short",
      "value": "0,08"
    },
    "413129451": {
      "type": "short",
      "value": "498"
    },
    "413129452": {
      "type": "short",
      "value": "24"
    },
    "413129453": {
      "type": "short",
      "value": "4"
    }
  },
  "swwwzd": {
    "407808159": {
      "type": "mc",
      "text": "mang thông tin qui định cấu trúc protein ức chế."
    },
    "407808160": {
      "type": "mc",
      "text": "vùng khởi động - vùng vận hành - nhóm gene cấu trúc."
    },
    "407808161": {
      "type": "mc",
      "text": "Protein ức chế bám vào vùng vận hành nên vùng khởi động bắt đầu hoạt động."
    },
    "407808162": {
      "type": "mc",
      "text": "lactose."
    },
    "407808163": {
      "type": "mc",
      "text": "vùng khởi động – vùng vận hành – nhóm gene cấu trúc (Z, Y, A)"
    },
    "407808164": {
      "type": "mc",
      "text": "Gene điều hòa (R)."
    },
    "407808165": {
      "type": "mc",
      "text": "vùng khởi động."
    },
    "407808166": {
      "type": "mc",
      "text": "tổng hợp các loại enzyme tham gia vào phản ứng phân giải đường lactose."
    },
    "407808167": {
      "type": "mc",
      "text": "vận hành."
    },
    "407808168": {
      "type": "mc",
      "text": "vùng vận hành."
    },
    "407808169": {
      "type": "mc",
      "text": "P (promoter)."
    },
    "407808170": {
      "type": "mc",
      "text": "Protein ức chế liên kết với vùng vận hành ngăn cản quá trình phiên mã của các gene cấu trúc."
    },
    "407808171": {
      "type": "mc",
      "text": "protein ức chế có thể liên kết làm ngăn cản sự phiên mã."
    },
    "407808172": {
      "type": "mc",
      "text": "Gene điều hòa R tổng hợp protein ức chế."
    },
    "407808173": {
      "type": "mc",
      "text": "Các gene của operon được phiên mã liên tục."
    },
    "407808174": {
      "type": "mc",
      "text": "Vùng vận hành (O), nhóm gene cấu trúc, vùng khởi động (P)."
    },
    "407808175": {
      "type": "mc",
      "text": "Operon là một nhóm gene cấu trúc có chung một trình tự promoter và kết hợp với một gene điều hòa có nhiệm vụ điều hòa phiên mã của cả nhóm gene cấu trúc nói trên cùng lúc"
    },
    "407808176": {
      "type": "mc",
      "text": "Đường lactose."
    },
    "407808177": {
      "type": "mc",
      "text": "Nơi tiếp xúc với enzyme RNA polymerase."
    },
    "407808178": {
      "type": "mc",
      "text": "Vì lactose làm mất cấu hình không gian của nó."
    },
    "407808179": {
      "type": "mc",
      "text": "Khi môi trường không có lactose."
    },
    "407808180": {
      "type": "mc",
      "text": "Mất gene điều hòa"
    },
    "407808181": {
      "type": "mc",
      "text": "Trong cơ thể sinh vật nhân thực đa bào, các tế bào khác nhau được biệt hóa về các chức năng khác nhau."
    },
    "407808182": {
      "type": "mc",
      "text": "3 loại protein tương ứng của 3 gene Z, Y, A hình thành 3 loại enzyme phân hủy lactose"
    },
    "407808183": {
      "type": "mc",
      "text": "Các gene cấu trúc"
    },
    "407808184": {
      "type": "mc",
      "text": "Gene điều hòa R không có vùng O nên không bị ức chế."
    },
    "407808185": {
      "type": "mc",
      "text": "Sự phiên mã bị kìm hãm khi chất ức chế gắn vào vùng O và diễn ra bình thường khi chất cảm ứng làm bất hoạt chất ức chế"
    },
    "407808186": {
      "type": "mc",
      "text": "Đột biến xảy ra ở vùng vận hành làm protein ức chế không thể gắn vào vùng vận hành được nên RNA polymerase hoạt động phiên mã"
    },
    "407808187": {
      "type": "mc",
      "text": "Vùng vận hành (O) nằm trước gene cấu trúc, là vị trí tương tác protein ức chế"
    }
  },
  "btz6mn": {
    "407809214": {
      "type": "tf",
      "items": [
        {
          "text": "O là là trình tự khởi động phiên mã các gene cấu trúc.",
          "value": "Sai"
        },
        {
          "text": "I là gene điều hòa mã hóa protein ức chế.",
          "value": "Đúng"
        },
        {
          "text": "Plac trình tự vận hành có vị trí bám của protein ức chế.",
          "value": "Sai"
        },
        {
          "text": "Z, Y, A là các gene cấu trúc tương ứng mã hóa cho các enzyme beta – galactosidase, permease, transacetylase.",
          "value": "Đúng"
        }
      ]
    },
    "407809215": {
      "type": "tf",
      "items": [
        {
          "text": "Allolactose, đồng phân của lactose đóng vai trò là chất cảm ứng.",
          "value": "Đúng"
        },
        {
          "text": "A: trong môi trường có lactose, B: trong môi trường không có lactose.",
          "value": "Sai"
        },
        {
          "text": "Protein ức chế luôn được tạo ra khi môi trường có lactose và không có lactose.",
          "value": "Đúng"
        },
        {
          "text": "Trong môi trường không có lactose thì RNA polymerase liên kết vào P, nhờ đó quá trình phiên mã xảy ra.",
          "value": "Sai"
        }
      ]
    },
    "407809216": {
      "type": "tf",
      "items": [
        {
          "text": "Nếu gene điều hòa nhân đôi 4 lần thì gene A nhân đôi 8 lần.",
          "value": "Sai"
        },
        {
          "text": "Nếu gene Y tạo ra 6 phân tử mRNA thì gene Z cũng tạo ra 6 phân tử mRNA.",
          "value": "Sai"
        },
        {
          "text": "Nếu gene A nhân đôi 1 lần thì gene Z cũng nhân đôi 1 lần.",
          "value": "Đúng"
        },
        {
          "text": "Quá trình phiên mã của gene Y nếu có nitrogenuos base dạng hiếm thì có thể phát sinh đột biến gene.",
          "value": "Đúng"
        }
      ]
    },
    "407809217": {
      "type": "tf",
      "items": [
        {
          "text": "Trên phân tử mRNA 2 chỉ chứa một codon mở đầu và một côđon kết thúc dịch mã.",
          "value": "Sai"
        },
        {
          "text": "Gene điều hòa (R) không nằm trong thành phần của operon Lac.",
          "value": "Đúng"
        },
        {
          "text": "Khi môi trường không có lactose thì gene điều hòa (R) vẫn có thể phiên mã.",
          "value": "Đúng"
        },
        {
          "text": "Nếu gene cấu trúc A và gene cấu trúc Z đều phiên mã 1 lần thì gene cấu trúc Y sẽ phiên mã 2 lần.",
          "value": "Sai"
        }
      ]
    },
    "407809218": {
      "type": "tf",
      "items": [
        {
          "text": "Điều hòa hoạt động gene phức tạp ở sinh vật nhân thực còn ở sinh vật nhân sơ thì đơn giản",
          "value": "Sai"
        },
        {
          "text": "Ở người phụ nữ bình thường, 1 trong 2 NST X bị bất hoạt bằng cách xoắn chặt lại hình thành Barr là một ví dụ về điều hòa hoạt động gene",
          "value": "Đúng"
        },
        {
          "text": "Gene điều hòa R đóng vai trò quan trọng trong điều hòa hoạt động gene nên phải thuộc thành phần của operon",
          "value": "Sai"
        },
        {
          "text": "Các gene quy định tổng hợp các enzyme tham gia vào các phản ứng phân giải đường lactose được phân bố liền nhau từng cụm",
          "value": "Đúng"
        }
      ]
    }
  },
  "mx3f3l": {
    "414976574": {
      "type": "short",
      "value": "2"
    },
    "414976575": {
      "type": "short",
      "value": "4"
    },
    "414976576": {
      "type": "short",
      "value": "5"
    },
    "414976577": {
      "type": "short",
      "value": "3"
    },
    "414976578": {
      "type": "short",
      "value": "5"
    },
    "414976579": {
      "type": "short",
      "value": "3"
    }
  },
  "pceb4s": {
    "414978873": {
      "type": "mc",
      "text": "4."
    },
    "414978874": {
      "type": "mc",
      "text": "Sợi siêu xoắn."
    },
    "414978875": {
      "type": "mc",
      "text": "Sợi nhiễm sắc."
    },
    "414978876": {
      "type": "mc",
      "text": "sợi cơ bản."
    },
    "414978877": {
      "type": "mc",
      "text": "mất đoạn"
    },
    "414978878": {
      "type": "mc",
      "text": "Lặp đoạn"
    },
    "414978879": {
      "type": "mc",
      "text": "đảo đoạn."
    },
    "414978880": {
      "type": "mc",
      "text": "chuyển đoạn tương hỗ"
    },
    "414978881": {
      "type": "mc",
      "text": "Chuyển đoạn không tương hỗ"
    },
    "414978882": {
      "type": "mc",
      "text": "Mất đoạn và lặp đoạn."
    },
    "414978883": {
      "type": "mc",
      "text": "DE●GHIK."
    },
    "414978884": {
      "type": "mc",
      "text": "ADCBE●GHIHIK"
    },
    "414978885": {
      "type": "mc",
      "text": "ADCBE●GHIK"
    },
    "414978886": {
      "type": "mc",
      "text": "Đảo đoạn."
    },
    "414978887": {
      "type": "mc",
      "text": "ADE●GHIK"
    },
    "414978888": {
      "type": "mc",
      "text": "Đa bội."
    },
    "414978889": {
      "type": "mc",
      "text": "0,25"
    },
    "414978890": {
      "type": "mc",
      "text": "Mất đoạn nhỏ."
    },
    "414978891": {
      "type": "mc",
      "text": "Đảo đoạn."
    },
    "414978892": {
      "type": "mc",
      "text": "Mất đoạn."
    },
    "414978893": {
      "type": "mc",
      "text": "Đảo đoạn nhiễm sắc thể."
    },
    "414978894": {
      "type": "mc",
      "text": "Lặp đoạn NST."
    },
    "414978895": {
      "type": "mc",
      "text": "Chuyển đoạn"
    },
    "414978896": {
      "type": "mc",
      "text": "15"
    },
    "414978897": {
      "type": "mc",
      "text": "Lặp đoạn."
    },
    "414978898": {
      "type": "mc",
      "text": "27."
    },
    "414978899": {
      "type": "mc",
      "text": "Thể tứ bội."
    },
    "414978900": {
      "type": "mc",
      "text": "Một đoạn nhiễm sắc thể nào đó đứt ra rồi đảo ngược 1800 và nối lại."
    },
    "414978901": {
      "type": "mc",
      "text": "đảo đoạn."
    },
    "414978902": {
      "type": "mc",
      "text": "Chuyển đoạn giữa hai nhiễm sắc thể không tương đồng."
    },
    "414978903": {
      "type": "mc",
      "text": "Mất đoạn và lặp đoạn nhiễm sắc thể."
    },
    "414978904": {
      "type": "mc",
      "text": "AaBbDEe."
    },
    "414978905": {
      "type": "mc",
      "text": "11."
    },
    "414978906": {
      "type": "mc",
      "text": "Giao tử (n) kết hợp với giao tử (2n)."
    },
    "414978907": {
      "type": "mc",
      "text": "4n."
    },
    "414978908": {
      "type": "mc",
      "text": "Thể một."
    },
    "414978909": {
      "type": "mc",
      "text": "Thể song nhị bội."
    },
    "414978910": {
      "type": "mc",
      "text": "thể dị đa bội."
    },
    "414978911": {
      "type": "mc",
      "text": "Thể ba."
    },
    "414978912": {
      "type": "mc",
      "text": "4n."
    },
    "414978913": {
      "type": "mc",
      "text": "Thể tam bội."
    },
    "414978914": {
      "type": "mc",
      "text": "Đảo đoạn NST."
    },
    "414978915": {
      "type": "mc",
      "text": "Thể ba NST số 21."
    },
    "414978916": {
      "type": "mc",
      "text": "11 và 18."
    },
    "414978917": {
      "type": "mc",
      "text": "2 cây thân cao : 1 cây thân thấp."
    },
    "414978918": {
      "type": "mc",
      "text": "AAaa × AAaa."
    },
    "414978919": {
      "type": "mc",
      "text": "AAaa × AAaa."
    },
    "414978920": {
      "type": "mc",
      "text": "Hai nhiễm sắc thể luôn ở trạng thái đơn giống hệt nhau mang tính chất hai nguồn gốc"
    },
    "414978921": {
      "type": "mc",
      "text": "Giúp các NST trượt trên thoi vô sắc về cực tế bào trong quá trình phân bào"
    },
    "414978922": {
      "type": "mc",
      "text": "Lõi là 8 phân tử protein histon, phía ngoài được một đoạn DNA gồm 146 cặp nu quấn 7/4 vòng"
    },
    "414978923": {
      "type": "mc",
      "text": "Nucleosome – Sợi cơ bản – Sợi nhiễm sắc– NST"
    },
    "414978924": {
      "type": "mc",
      "text": "Đột biến chuyển đoạn NST thường làm giảm sức sống của sinh vật"
    },
    "414978925": {
      "type": "mc",
      "text": "Bệnh ung thư máu"
    },
    "414978926": {
      "type": "mc",
      "text": "Có một đột biến lặp đoạn NST"
    },
    "414978927": {
      "type": "mc",
      "text": "Người bị bệnh ung thư máu."
    }
  },
  "hz3tbh": {
    "424152471": {
      "type": "mc",
      "text": "toàn bộ lượng vật chất di truyền trong tế bào của sinh vật"
    },
    "424152472": {
      "type": "mc",
      "text": "tập hợp phân tử DNA trên NST trong nhân tế bào và trong bào quan ti thể, lục lạp"
    },
    "424152473": {
      "type": "mc",
      "text": "Tập hợp các phân tử DNA vòng trong vùng nhân và plasmid"
    },
    "424152474": {
      "type": "mc",
      "text": "2000"
    },
    "424152475": {
      "type": "mc",
      "text": "2003"
    },
    "424152476": {
      "type": "mc",
      "text": "1990"
    },
    "424152477": {
      "type": "mc",
      "text": "2001"
    },
    "424152478": {
      "type": "mc",
      "text": "vi khuẩn"
    },
    "424152479": {
      "type": "mc",
      "text": "Quy trình tạo những tế bào hoặc sinh vật có gene bị biến đổi hoặc có thêm gene mới"
    },
    "424152480": {
      "type": "mc",
      "text": "Kĩ thuật tạo DNA tái tổ hợp"
    },
    "424152481": {
      "type": "mc",
      "text": "Là phân tử DNA hình thành từ sự nối hai hay nhiều đoạn DNA cùng nguồn hoặc khác nguồn"
    },
    "424152482": {
      "type": "mc",
      "text": "Công nghệ DNA tái tổ hợp"
    },
    "424152483": {
      "type": "mc",
      "text": "Cắt đoạn DNA ngoại lai và vector tại những vị trí nhận biết đặc hiệu."
    },
    "424152484": {
      "type": "mc",
      "text": "Virus hoặc plasmid"
    },
    "424152485": {
      "type": "mc",
      "text": "Có thể ức chế gene của tế bào nhận để gene cần chuyển biểu hiện tính trạng."
    },
    "424152486": {
      "type": "mc",
      "text": "Nếu không có thể truyền thì khó có thể thu được nhiều sản phẩm của gene trong tế bào nhận"
    },
    "424152487": {
      "type": "mc",
      "text": "Nhận biết các tế bào đã nhận được DNA tái tổ hợp."
    },
    "424152488": {
      "type": "mc",
      "text": "Kích thước càng lớn càng tốt để mang gene."
    },
    "424152489": {
      "type": "mc",
      "text": "Restrictase (endonuclease) chỉ được dùng để tạo ra các đầu dính ở thể truyền"
    },
    "424152490": {
      "type": "mc",
      "text": "2, 1, 4, 3"
    },
    "424152491": {
      "type": "mc",
      "text": "Có trong tế bào chất của vi khuẩn ,virus"
    },
    "424152492": {
      "type": "mc",
      "text": "ligase"
    },
    "424152493": {
      "type": "mc",
      "text": "tạo DNA tái tổ hợp → đưa DNA tái tổ hợp vào trong tế bào nhận → phân lập dòng tế bào chứa DNA tái tổ hợp"
    },
    "424152494": {
      "type": "mc",
      "text": "Có hàng trăm loại enzyme DNA-restrictase khác nhau, có khả năng nhận biết và cắt phân tử DNA ở những vị trí đặc hiệu, các enzyme này chỉ được phân lập từ động vật bậc cao"
    },
    "424152495": {
      "type": "mc",
      "text": "Cắt, nối DNA của tế bào cho và DNA plasmid ở những điểm xác định tạo DNA tái tổ hợp"
    },
    "424152496": {
      "type": "mc",
      "text": "nhận ra và cắt đứt DNA ở những trình tự nucleotide xác định"
    },
    "424152497": {
      "type": "mc",
      "text": "Làm dãn màng sinh chất của tế bào để phân tử DNA dễ đi vào bên trong"
    },
    "424152498": {
      "type": "mc",
      "text": "Tinh sạch DNA mang gene mong muốn - cắt DNA mang gene và DNA của plasmid bởi cùng một enzyme - dùng enzyme gắn đoạn DNA mang gene vào DNA plasmit, đóng vòng DNA plasmid"
    },
    "424152499": {
      "type": "mc",
      "text": "Nối gene của tế bào cho và plasmid của vi khuần tạo nên DNA tái tổ hợp"
    },
    "424152500": {
      "type": "mc",
      "text": "Sinh trưởng và phát triển bình thường."
    },
    "424152501": {
      "type": "mc",
      "text": "Tổ hợp lại các gene vốn có của bố mẹ bằng lai hữu tính."
    },
    "424152502": {
      "type": "mc",
      "text": "Hạ giá thành sản phẩm."
    },
    "424152503": {
      "type": "mc",
      "text": "Gene cần chuyển."
    },
    "424152504": {
      "type": "mc",
      "text": "Chuyển gene bằng thực khuẩn thể."
    },
    "424152505": {
      "type": "mc",
      "text": "1"
    },
    "424152506": {
      "type": "mc",
      "text": "Gene đánh dấu."
    },
    "424152507": {
      "type": "mc",
      "text": "Gene sản sinh ra ethylen đã bị bất hoạt"
    },
    "424152508": {
      "type": "mc",
      "text": "Công nghệ gene"
    },
    "424152509": {
      "type": "mc",
      "text": "(1)→(2)→(3)→(4)"
    },
    "424152510": {
      "type": "mc",
      "text": "Sữa"
    },
    "424152511": {
      "type": "mc",
      "text": "Lấy trứng của con cái rồi cho thụ tinh trong ống nghiệm, sau đó đưa gene vào hợp tử (ở giai đoạn nhân con), cho hợp tử phát triển thành phôi rồi cấy phôi đã chuyển gene vào tử cung con cái"
    },
    "424152512": {
      "type": "mc",
      "text": "Enzyme Restrictase (endonuclease) và enzyme ligase"
    },
    "424152513": {
      "type": "mc",
      "text": "Công nghệ gene"
    },
    "424152514": {
      "type": "mc",
      "text": "Công nghệ gene"
    },
    "424152515": {
      "type": "mc",
      "text": "Cắt lần thứ hai đoạn DNA băng restrictase B, rồi cài vào thể truyền sau khi đã cắt bằng cùng loại enzyme giới hạn này."
    },
    "424152516": {
      "type": "mc",
      "text": "Công nghệ gene"
    },
    "424152517": {
      "type": "mc",
      "text": "(M): E.Coli, (N): sinh sản rất nhanh"
    },
    "424152518": {
      "type": "mc",
      "text": "Chuyển gene bằng thực khuẩn thể."
    },
    "424152519": {
      "type": "mc",
      "text": "(1) sai, (2) đúng, (3)sai, (4) đúng."
    },
    "424152520": {
      "type": "mc",
      "text": "dùng kĩ thuật chuyển gene nhờ vector là plasmid."
    },
    "424152521": {
      "type": "mc",
      "text": "DNA tái tổ hợp này có khả năng xâm nhập vào tế bào nhận bằng phương pháp tải nạp"
    },
    "424152522": {
      "type": "mc",
      "text": "Kĩ thuật DNA tái tổ hợp"
    }
  },
  "pwauub": {
    "424153345": {
      "type": "tf",
      "items": [
        {
          "text": "Hệ gene là toàn bộ lượng vật chất di truyền trong tế bào của sinh vật",
          "value": "Đúng"
        },
        {
          "text": "Hệ gene của sinh vật nhân thực bao gồm tập hợp phân tử DNA trên NST trong nhân tế bào và trong bào quan ti thể, lục lạp",
          "value": "Đúng"
        },
        {
          "text": "Việc hoàn thành giải trình tự hệ gene người lần đầu vào năm 2001",
          "value": "Sai"
        },
        {
          "text": "Hệ gene của sinh vật nhân sơ bao gồm tập hợp phân tử DNA vòng trên NST trong nhân tế bào và trong bào quan ti thể, lục lạp",
          "value": "Sai"
        }
      ]
    },
    "424153346": {
      "type": "tf",
      "items": [
        {
          "text": "Dự án giải trình tự hệ gene người bắt đầu vào năm 1990",
          "value": "Đúng"
        },
        {
          "text": "Dự án giải trình tự hệ gene người kết thúc vào năm 2001",
          "value": "Sai"
        },
        {
          "text": "Việc hoàn thành giải trình tự hệ gene người lần đầu vào năm 2000.",
          "value": "Đúng"
        },
        {
          "text": "Dự án giải trình tự hệ gene người chính thức công bố vào năm 2003",
          "value": "Sai"
        }
      ]
    },
    "424153347": {
      "type": "tf",
      "items": [
        {
          "text": "Tế bào nhận gene là sinh vật nhân thực.",
          "value": "Sai"
        },
        {
          "text": "Gene cần chuyển và thể truyền cần được cắt bởi cùng một loại enzym ligase.",
          "value": "Sai"
        },
        {
          "text": "Gene cần chuyển có thể lấy trực tiếp từ tế bào sống hoặc được tổng hợp nhân tạo.",
          "value": "Đúng"
        },
        {
          "text": "Một số DNA tái tổ hợp có thể xâm nhập vào tế bào nhận mà không cần phải làm dãn màng sinh chất của tế bào nhận.",
          "value": "Đúng"
        }
      ]
    },
    "424153348": {
      "type": "tf",
      "items": [
        {
          "text": "Sẽ không tạo ra được sản phẩm như mong muốn vì cơ chế di truyền ở cấp độ phân tử của ecoli không phù hợp với hệ gene người",
          "value": "Đúng"
        },
        {
          "text": "Do đoạn DNA của người là đoạn gene phân mảnh, còn vi khuẩn có hệ gene không phân mảnh.",
          "value": "Đúng"
        },
        {
          "text": "Gene của người không thể phiên mã được trong tế bào vi khuẩn.",
          "value": "Sai"
        },
        {
          "text": "DNA của người tồn tại trong nhân nên không thể hoạt động được trong tế bào vi khuẩn.",
          "value": "Sai"
        }
      ]
    },
    "424153349": {
      "type": "tf",
      "items": [
        {
          "text": "Một số DNA tái tổ hợp có thể xâm nhập vào tế bào nhận mà không cần phải làm dãn màng sinh chất của tế bào nhận",
          "value": "Đúng"
        },
        {
          "text": "Có hàng trăm loại enzyme DNA-restrictase khác nhau, có khả năng nhận biết và cắt phân tử DNA ở những vị trí đặc hiệu, các enzyme này chỉ được phân lập từ động vật bậc cao",
          "value": "Sai"
        },
        {
          "text": "Endonuclease và ligase tham gia vào công đoạn chuyển DNA tái tổ hợp vào tế bào nhận",
          "value": "Sai"
        },
        {
          "text": "Người ta sử dụng CaCl2 hoặc xung điện trong bước đưa DNA tái tổ hợp vào tế bào nhận nhằm làm dãn màng sinh chất của tế bào để phân tử DNA dễ đi vào bên trong",
          "value": "Đúng"
        }
      ]
    },
    "424153350": {
      "type": "tf",
      "items": [
        {
          "text": "Gene đánh dấu có chức năng phát hiện tế bào đã nhận DNA tái tổ hợp.",
          "value": "Đúng"
        },
        {
          "text": "Các đoạn DNA được nối lại với nhau nhờ xúc tác của enzyme DNA – ligase",
          "value": "Đúng"
        },
        {
          "text": "DNA tái tổ hợp phải từ hai nguồn DNA có quan hệ loài gần gũi.",
          "value": "Sai"
        },
        {
          "text": "Plasmid là thể truyền duy nhất được sử dụng trong kĩ thuật chuyển gene.",
          "value": "Sai"
        }
      ]
    },
    "424153351": {
      "type": "tf",
      "items": [
        {
          "text": "Gene quy định tổng hợp kháng sinh của vi khuẩn hoạt động độc lập với hệ gene vùng nhân.",
          "value": "Sai"
        },
        {
          "text": "Gene ngoài tế bào chất của vi khuẩn mang gene của 2 loài sinh vật khác nhau.",
          "value": "Đúng"
        },
        {
          "text": "Do hệ gene đã bị đột biến, nếu thêm vào môi trường penicillin (một loại kháng sinh) thì vi khuẩn vẫn sinh trưởng bình thường.",
          "value": "Sai"
        },
        {
          "text": "Vi khuẩn mang cả 2 gene trong nhân tế bào, một gene kháng tetracyclin, một gene kháng ampicyllin.",
          "value": "Đúng"
        }
      ]
    },
    "424153352": {
      "type": "tf",
      "items": [
        {
          "text": "Trong môi trường tạo DNA tái tổ hợp, chỉ cần trong môi trường có ligase, DNA cho và plasmid thì luôn tạo thành DNA tái tổ hợp.",
          "value": "Sai"
        },
        {
          "text": "Enzyme DNA ligase có vai trò tạo cầu nối photphodieste để hình thành nên đoạn DNA tái tổ hợp.",
          "value": "Đúng"
        },
        {
          "text": "DNA tái tổ hợp được hình thành khi đầu dính của DNA cho và nhận khớp bổ sung với nhau.",
          "value": "Đúng"
        },
        {
          "text": "Để tách dòng tế bào DNA tái tổ hợp, không thể sử dụng các gene đánh dấu là các gene kháng kháng sinh.",
          "value": "Sai"
        }
      ]
    }
  },
  "jpbwbd": {
    "424153750": {
      "type": "short",
      "value": "2000"
    },
    "424153751": {
      "type": "short",
      "value": "2003"
    },
    "424153752": {
      "type": "short",
      "value": "1990"
    },
    "424153753": {
      "type": "short",
      "value": "2001"
    },
    "424153754": {
      "type": "short",
      "value": "3"
    },
    "424153755": {
      "type": "short",
      "value": "3"
    },
    "424153756": {
      "type": "short",
      "value": "5"
    },
    "424153757": {
      "type": "short",
      "value": "2"
    },
    "424153758": {
      "type": "short",
      "value": "1"
    },
    "424153759": {
      "type": "short",
      "value": "1"
    },
    "424153760": {
      "type": "short",
      "value": "2"
    },
    "424153761": {
      "type": "short",
      "value": "3"
    },
    "424153762": {
      "type": "short",
      "value": "2"
    },
    "424153763": {
      "type": "short",
      "value": "3"
    },
    "424153764": {
      "type": "short",
      "value": "3"
    },
    "424153765": {
      "type": "short",
      "value": "3"
    }
  }
};
