// background.js – Service worker (MV3)
// Nhiệm vụ duy nhất: fetch dữ liệu cập nhật từ URL, validate, lưu vào chrome.storage.local.
// Nếu fetch lỗi (server chết, mất mạng) → trả về error, KHÔNG xoá cache cũ.

const UPDATE_URL_DEFAULT = "http://127.0.0.1:8080/data.json";

const CHECK_ALARM = "azota.checkUpdate";       // check định kỳ
const ONE_DAY_MIN = 24 * 60;                   // 1 ngày tính bằng phút

// ── Helpers ────────────────────────────────────────────────────────────────
async function getSettings() {
  return await chrome.storage.sync.get({
    updateUrl: UPDATE_URL_DEFAULT,
    autoCheck: true,
  });
}

async function getCache() {
  return await chrome.storage.local.get({
    remoteData: null,        // { version, codes, exams }
    remoteMeta: null,        // { fetchedAt, ok, error, version, codes }
  });
}

function setCache(remoteData, meta) {
  return chrome.storage.local.set({ remoteData, remoteMeta: meta });
}

async function fetchRemote(url) {
  const res = await fetch(url, {
    cache: "no-cache",
    headers: { "Accept": "application/json" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); }
  catch (e) { throw new Error("JSON parse error"); }
  // Validate tối thiểu
  if (!json || typeof json !== "object") throw new Error("Invalid payload");
  if (!json.exams || typeof json.exams !== "object") throw new Error("Missing exams");
  return json;
}

// ── Hàm check update chính ─────────────────────────────────────────────────
async function checkUpdate({ silent = false } = {}) {
  const { updateUrl, autoCheck } = await getSettings();
  if (!updateUrl) return { ok: false, reason: "no-url" };

  try {
    const remote = await fetchRemote(updateUrl);
    const meta = {
      fetchedAt: Date.now(),
      ok: true,
      version: remote.version ?? null,
      codes: Array.isArray(remote.codes) ? remote.codes.length : Object.keys(remote.exams || {}).length,
    };
    await setCache(remote, meta);
    // Nếu là silent (alarm) và autoCheck tắt → vẫn lưu nhưng không thông báo
    if (!silent) {
      try {
        const last = (await chrome.storage.local.get("lastNotifiedVersion")).lastNotifiedVersion;
        if (last !== meta.version && meta.version != null) {
          await chrome.storage.local.set({ lastNotifiedVersion: meta.version });
          // (không gọi notification ở đây; popup sẽ hiển thị khi user mở)
        }
      } catch {}
    }
    return { ok: true, ...meta };
  } catch (err) {
    const msg = (err && err.message) || String(err);
    // Giữ cache cũ; chỉ cập nhật meta
    const cache = await getCache();
    const meta = {
      ...(cache.remoteMeta || {}),
      fetchedAt: Date.now(),
      ok: false,
      error: msg,
    };
    await chrome.storage.local.set({ remoteMeta: meta });
    return { ok: false, reason: "fetch-failed", error: msg };
  }
}

// ── Lắng nghe message từ popup ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "AZOTA_CHECK_UPDATE") {
    checkUpdate({ silent: false }).then(sendResponse);
    return true; // async
  }
  if (msg?.type === "AZOTA_GET_UPDATE_STATUS") {
    (async () => {
      const { updateUrl, autoCheck } = await getSettings();
      const { remoteData, remoteMeta } = await getCache();
      sendResponse({ updateUrl, autoCheck, remoteData, remoteMeta });
    })();
    return true;
  }
  if (msg?.type === "AZOTA_SET_UPDATE_URL") {
    chrome.storage.sync.set({ updateUrl: msg.url }).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "AZOTA_CLEAR_REMOTE") {
    chrome.storage.local.remove(["remoteData", "remoteMeta"]).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "AZOTA_SET_AUTOCHECK") {
    chrome.storage.sync.set({ autoCheck: !!msg.value }).then(async () => {
      if (msg.value) {
        await chrome.alarms.create(CHECK_ALARM, { periodInMinutes: ONE_DAY_MIN });
        // Check ngay một lần
        checkUpdate({ silent: true });
      } else {
        await chrome.alarms.clear(CHECK_ALARM);
      }
      sendResponse({ ok: true });
    });
    return true;
  }
});

// ── Alarm định kỳ ──────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === CHECK_ALARM) {
    checkUpdate({ silent: true });
  }
});

// ── Khởi động ──────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const { autoCheck } = await getSettings();
  if (autoCheck) {
    chrome.alarms.create(CHECK_ALARM, { periodInMinutes: ONE_DAY_MIN });
  }
  // Check ngay 1 lần lúc cài (silent — không thông báo)
  checkUpdate({ silent: true });
});

chrome.runtime.onStartup.addListener(async () => {
  const { autoCheck } = await getSettings();
  if (autoCheck) {
    chrome.alarms.create(CHECK_ALARM, { periodInMinutes: ONE_DAY_MIN });
    checkUpdate({ silent: true });
  }
});
